const CHART_THEME = {
  axisLine:'#D7DEE6', gridLine:'#EEF1F5', gridLineLight:'#F4F6F8',
  axisText:'#8A95A3', darkText:'#1A1F2B', mutedText:'#667085',
  mutedText2:'#8FA3A1', errorText:'#DC4444', cardBg:'#FFFFFF'
};
function applyDarkChartTheme(isDark){
  if(isDark){
    Object.assign(CHART_THEME, {
      axisLine:'#33424F', gridLine:'#243140', gridLineLight:'#1C2733',
      axisText:'#8FA0AD', darkText:'#E8EEF3', mutedText:'#9AABB8',
      mutedText2:'#6E8088', errorText:'#FF6B6B', cardBg:'#16202B'
    });
  } else {
    Object.assign(CHART_THEME, {
      axisLine:'#D7DEE6', gridLine:'#EEF1F5', gridLineLight:'#F4F6F8',
      axisText:'#8A95A3', darkText:'#1A1F2B', mutedText:'#667085',
      mutedText2:'#8FA3A1', errorText:'#DC4444', cardBg:'#FFFFFF'
    });
  }
}

const AssetDash = (function(){

// ===================== CONFIG =====================
const PILAR_ORDER = ['Inventário','Taxonomia','Lista BOM','Estratégia de Manutenção','RCM'];
const CHART_PILARES = PILAR_ORDER.filter(p=>p!=='RCM');
const PILAR_COLOR_HEX = {
  'Inventário': '#007E7A',
  'Taxonomia': '#00B0CA',
  'Lista BOM': '#69BE28',
  'Estratégia de Manutenção': '#EDB111',
  'RCM': '#747678'
};
const CONS_COLOR = '#1E8449'; // verde escuro — exclusivo da linha de "Realizado" consolidada (múltiplos pilares)
const PILAR_MAP = {
  'Estrategia de ativos (RCM)':'RCM',
  'RCM':'RCM',
  'TAXONOMIA':'Taxonomia',
  'LISTA BOM':'Lista BOM',
  'ESTRATEGIA DE ATIVOS':'Estratégia de Manutenção',
  'Inventário':'Inventário'
};

const DEFAULT_DATA = []; // o dashboard inicia sem dados — os itens entram pelo upload da planilha 🪨 Britagem III


const ENERGIA_DATA = []; // o dashboard inicia sem dados — os itens entram pelo upload da planilha ⚡ Energia

// ===================== ÁREA ATIVA (Britagem / Energia) =====================
let currentArea = 'britagem';
const AREA_LABEL = { britagem:'Britagem', energia:'Energia' };
const AREA_FLUXO_TITLE = {
  britagem:'Fluxograma de blocos — Processo de Britagem',
  energia:'Fluxograma de blocos — Distribuição de Energia'
};
const AREA_FLUXO_SUB = {
  britagem:'Hierarquia de ativos do SAP (4º nível) com avanço em tempo real — clique em "Equipes" abaixo para entender cada sigla',
  energia:'Hierarquia de ativos do SAP (4º nível) — linha de transmissão, SE principal, alimentadores e subestações unitárias com avanço em tempo real'
};
const areaItems = { britagem: DEFAULT_DATA.slice(), energia: ENERGIA_DATA.slice() };

let items = areaItems[currentArea];
let selectedIndividual = new Set(CHART_PILARES);
let selectedConsolidada = new Set(CHART_PILARES);
let mapaGranularidade = 'mes';

// ---------- fluxograma de blocos (taxonomia SAP / processo de britagem) ----------
const SISTEMA_META_BRITAGEM = {
  BRT01: {label:'Britagem primária',    sub:'Britador giratório · 2101', group:'main',  color:'#007E7A'},
  EST01: {label:'Alimentação / Pilha',  sub:'Retomada ROM britado · 2103', group:'main', color:'#00B0CA'},
  BRT02: {label:'Britagem secundária',  sub:'Linha 1 · 2104',  group:'main',  color:'#0F6E56'},
  BRT03: {label:'Britagem secundária',  sub:'Linha 2 · 2104',  group:'main',  color:'#0F6E56'},
  BRT04: {label:'Silo / Transporte',    sub:'Regularização · 2104', group:'main', color:'#045552'},
  EQA01: {label:'Equip. auxiliares',    sub:'Apoio britagem primária', group:'aux', color:'#8A95A3'},
  EQA03: {label:'Equip. auxiliares',    sub:'Apoio pilha / alimentação', group:'aux', color:'#8A95A3'},
  DRN01: {label:'Drenagem',             sub:'Apoio britagem secundária', group:'aux', color:'#8A95A3'},
  EQA02: {label:'Equip. auxiliares',    sub:'Apoio britagem secundária', group:'aux', color:'#8A95A3'},
  EDF01: {label:'Painel SDAI',          sub:'Prédio BRT II · 2104', group:'aux', color:'#8A95A3'},
};

const SISTEMA_META_ENERGIA = {
  LTR01: {label:'Linha de transmissão',   sub:'230 kV · Palmares – Carajás',      group:'main', color:'#007E7A'},
  SUB01: {label:'SE Principal',           sub:'230 kV · SE_8002 / SE_8011SA',     group:'main', color:'#045552'},
  DST01: {label:'Alimentadores 13,8 kV',  sub:'Distribuição principal · SE_8002', group:'main', color:'#00B0CA'},
  SUB02: {label:'SE Britagem primária',   sub:'inclui SE I do TCLD-03',           group:'sub',  color:'#0F6E56'},
  SUB03: {label:'SE Laboratório',         sub:'Físico-químico · TCLD-04',         group:'sub',  color:'#0F6E56'},
  SUB04: {label:'SE E-House Moinhos',     sub:'Moinho 01 · Moinho 02',            group:'sub',  color:'#0F6E56'},
  SUB05: {label:'SE Moagem / Flotação',   sub:'SLB1 · SLB2',                      group:'sub',  color:'#0F6E56'},
  SUB06: {label:'SE Britagem secundária', sub:'13,8 kV · área 2105',              group:'sub',  color:'#0F6E56'},
  SUB07: {label:'SE TCLD / HGPR',         sub:'área 2304',                        group:'sub',  color:'#0F6E56'},
  SUB08: {label:'SE Moagem',              sub:'área 2305',                        group:'sub',  color:'#0F6E56'},
  SUB09: {label:'SE Remoagem',            sub:'SLB1 · SLB2',                      group:'sub',  color:'#0F6E56'},
  SUB10: {label:'SE ETA / Filtragem',     sub:'Tratamento de água',               group:'sub',  color:'#0F6E56'},
  SUB11: {label:'SE Prensagem',           sub:'SLB1 · SLB2',                      group:'sub',  color:'#0F6E56'},
  SUB12: {label:'SE Captação de água',    sub:'Bruta · Recuperada',               group:'sub',  color:'#0F6E56'},
  SUB13: {label:'SE Filtragem concent.',  sub:'área 2021',                        group:'sub',  color:'#0F6E56'},
  SUB14: {label:'SE Eletrocentros',       sub:'Captação · E-House 2305',          group:'sub',  color:'#0F6E56'},
  SUB15: {label:'SE Oficina / Barragem',  sub:'Provisória · Mirim',               group:'sub',  color:'#0F6E56'},
  SUB16: {label:'SE Oficina provisória',  sub:'apoio',                            group:'sub',  color:'#0F6E56'},
  DST02: {label:'Distribuição',           sub:'alimentadores',                    group:'aux',  color:'#8A95A3'},
  DST03: {label:'Distribuição',           sub:'alimentadores',                    group:'aux',  color:'#8A95A3'},
  DST04: {label:'Distribuição',           sub:'alimentadores',                    group:'aux',  color:'#8A95A3'},
  DST05: {label:'Distribuição',           sub:'alimentadores',                    group:'aux',  color:'#8A95A3'},
  DST06: {label:'Distribuição',           sub:'alimentadores',                    group:'aux',  color:'#8A95A3'},
  DST07: {label:'Distribuição',           sub:'alimentadores',                    group:'aux',  color:'#8A95A3'},
  DST08: {label:'Distribuição',           sub:'alimentadores',                    group:'aux',  color:'#8A95A3'},
  DST09: {label:'Distribuição',           sub:'alimentadores',                    group:'aux',  color:'#8A95A3'},
};

let SISTEMA_META = SISTEMA_META_BRITAGEM;
let desvioViewMode = 'geral';
let desvioSubView = 'resumo'; // 'resumo' | 'atrasado'

function normalizeValidado(v){
  return (v||'').toString().toLowerCase().replace(/\./g,'').trim();
}
function classifyDelayCause(item){
  const v = normalizeValidado(item.validado);
  if(v.includes('em analise') || v.includes('em análise')){
    const dPrev = parseDate(item.retorno_previsto);
    const dReal = parseDate(item.retorno_real);
    if(dPrev && dReal && dReal > dPrev) return 'Vale';
    return null; // ainda dentro do prazo de retorno esperado
  }
  if(v === 'ag envio' || (item.status && item.status !== 'Concluído')){
    return 'Tenax';
  }
  return null;
}
let individualViewMode = 'pilar'; // 'pilar' | 'geral'

// Seletor exclusivo para consolidada: Todos ou 1 pilar
function renderTeamSelectConsolidada(){
  const counts = pilarCounts();
  const el = document.getElementById('a_teamSelectConsolidada');
  const allSelected = CHART_PILARES.every(p=>selectedConsolidada.has(p));
  const single = allSelected ? null : CHART_PILARES.find(p=>selectedConsolidada.has(p)) || null;

  const btnTodos = `<button class="team-chip${allSelected?' active-chip':''}" id="cons_btn_todos" style="${allSelected?`background:var(--teal);color:#fff;`:''}">Todos os pilares</button>`;
  const pilarBtns = CHART_PILARES.map(p=>{
    const active = !allSelected && selectedConsolidada.has(p);
    return `<button class="team-chip${active?' active-chip':''}" data-pilar="${p}"
      style="${active?`background:${PILAR_COLOR_HEX[p]};color:#fff;`:`color:${PILAR_COLOR_HEX[p]};`}">
      <span class="dot" style="background:${PILAR_COLOR_HEX[p]};"></span>${p} (${counts[p]?counts[p].total:0})
    </button>`;
  }).join('');

  el.innerHTML = btnTodos + pilarBtns;

  el.querySelector('#cons_btn_todos').addEventListener('click',()=>{
    CHART_PILARES.forEach(p=>selectedConsolidada.add(p));
    renderTeamSelectConsolidada(); renderCurvaConsolidada();
  });
  el.querySelectorAll('button[data-pilar]').forEach(btn=>{
    btn.addEventListener('click',()=>{
      selectedConsolidada.clear();
      selectedConsolidada.add(btn.dataset.pilar);
      renderTeamSelectConsolidada(); renderCurvaConsolidada();
    });
  });
}

function toISO(d){
  if(d===null || d===undefined || d==='') return null;
  const isDateLike = Object.prototype.toString.call(d) === '[object Date]';
  if(isDateLike){
    if(isNaN(d.getTime())) return null;
    const iso = d.toISOString().slice(0,10);
    if(iso === '1899-12-30' || iso === '1899-12-31') return null;
    return iso;
  }
  if(typeof d === 'number'){
    // serial de data do Excel (caso cellDates não tenha convertido)
    const parsed = XLSX.SSF.parse_date_code(d);
    if(!parsed) return null;
    const mm = String(parsed.m).padStart(2,'0'), dd = String(parsed.d).padStart(2,'0');
    return `${parsed.y}-${mm}-${dd}`;
  }
  if(typeof d === 'string'){
    const s = d.trim();
    // já em ISO yyyy-mm-dd
    if(/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0,10);
    // dd/mm/yyyy ou dd/mm/yy
    const m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
    if(m){
      let [_, dd, mm, yy] = m;
      if(yy.length===2) yy = '20'+yy;
      return `${yy}-${mm.padStart(2,'0')}-${dd.padStart(2,'0')}`;
    }
    return null;
  }
  return null;
}

// ---------- normalização de dados vindos da planilha ----------
// Extrai o sistema (4º nível) do código do ativo: COSB-BC3-BRT-BRT01-... -> BRT01
function sistemaFromAtivo(ativo){
  if(!ativo) return null;
  const parts = String(ativo).trim().split('-');
  return parts.length >= 4 ? parts[3].trim().toUpperCase() : null;
}
// Aceita variações de caixa/acentos/espaços no status da planilha
function normalizeStatus(raw, hasPlan){
  const v = (raw===null||raw===undefined) ? '' : String(raw).trim();
  const low = v.toLowerCase();
  if(!low) return hasPlan ? 'Não iniciado' : 'Não planejado';
  if(low.startsWith('conclu')) return 'Concluído';
  if(low.includes('andamento')) return 'Em andamento';
  if(low.includes('execu')) return 'Em execução';
  if(low.includes('planejado') && (low.includes('não')||low.includes('nao'))) return 'Não planejado';
  if(low.includes('iniciado') && (low.includes('não')||low.includes('nao'))) return 'Não iniciado';
  return v;
}

// Atualiza a área indicada (independente da área que está aberta na tela).
// area: 'britagem' | 'energia'
function rebuildAreaFromWorkbook(workbook, area){
  if(area==='energia') return rebuildEnergiaFromWorkbook(workbook);
  return rebuildBritagemFromWorkbook(workbook);
}

// compatibilidade: atualiza a área atualmente aberta
function rebuildFromWorkbook(workbook){
  return rebuildAreaFromWorkbook(workbook, currentArea);
}

// ---------- parser unificado da aba "Priorização Vale" ----------
// A MESMA lógica vale para os dois processos; muda apenas o filtro do 3º nível do FLOC.
const AREA_NIVEL3 = { britagem: ['BRT','EST'], energia: ['ENE'] };

// Escopo -> pilar (tolerante a maiúsculas, acentos e variações entre planilhas)
function normalizePilar(escopo){
  const v = (escopo===null||escopo===undefined) ? '' : String(escopo).trim().toLowerCase();
  if(!v) return null;
  if(v.includes('rcm')) return 'RCM';
  if(v.includes('taxonom')) return 'Taxonomia';
  if(v.includes('bom')) return 'Lista BOM';
  if(v.includes('invent')) return 'Inventário';
  if(v.includes('estrat')) return 'Estratégia de Manutenção';
  return null;
}

function parsePriorizacaoVale(workbook, area){
  const sheetName = workbook.SheetNames.find(n => n.trim().toLowerCase() === 'priorização vale')
    || workbook.SheetNames.find(n => n.trim().toLowerCase().includes('priorização vale'))
    || workbook.SheetNames.find(n => n.trim().toLowerCase().startsWith('prioriza'));
  if(!sheetName) throw new Error('aba "Priorização Vale" não encontrada nesta planilha');
  const rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {defval:null});
  const niveis3 = AREA_NIVEL3[area] || [];

  // trava de segurança: detecta se a planilha é do outro processo (evita sobrescrever dados com o arquivo errado)
  let nBRT = 0, nENE = 0;
  rows.forEach(r=>{
    const n3 = (r['3º nível']===null||r['3º nível']===undefined) ? '' : String(r['3º nível']).trim().toUpperCase();
    if(n3==='BRT') nBRT++;
    else if(n3==='ENE') nENE++;
  });
  if(area==='britagem' && nENE > nBRT){
    throw new Error('esta planilha parece ser do processo de ENERGIA (' + nENE + ' itens ENE contra ' + nBRT + ' BRT) — use o botão ⚡ Energia para ela');
  }
  if(area==='energia' && nBRT > nENE){
    throw new Error('esta planilha parece ser do processo de BRITAGEM (' + nBRT + ' itens BRT contra ' + nENE + ' ENE) — use o botão 🪨 Britagem III para ela');
  }

  const recs = [];
  rows.forEach(r=>{
    const n3 = (r['3º nível']===null||r['3º nível']===undefined) ? '' : String(r['3º nível']).trim().toUpperCase();
    if(!niveis3.includes(n3)) return;
    const pilar = normalizePilar(r['Escopo']);
    if(!pilar) return;

    const ativo = r['Local de Instalação'] || r['FLOC (Local de Instalação)'] || '';
    const denom = (r['Denominação do loc.instalação'] && r['Denominação do loc.instalação']!=='-') ? r['Denominação do loc.instalação'] : '';
    const sistemaRaw = (r['4º nível'] && r['4º nível']!=='-') ? String(r['4º nível']).trim().toUpperCase() : null;
    const sistema = sistemaRaw || sistemaFromAtivo(ativo) || '';
    const floc = (r['5º nível'] && r['5º nível']!=='-') ? String(r['5º nível'])
               : ((r['EGP'] && r['EGP']!=='-') ? String(r['EGP']) : '');

    const planStart = toISO(r['Data início planejado']);
    const planEnd = toISO(r['Data de conclusão planejada']);
    const realStart = toISO(r['Data real de início']);
    const realEnd = toISO(r['Data real de conclusão']);
    const status = normalizeStatus(r['Status'], !!(planStart || planEnd));

    // desvio: usa a coluna "Desvio padrão" quando numérica; senão calcula (real − planejado) em dias
    const desvioRaw = r['Desvio padrão'];
    let desvio = (typeof desvioRaw === 'number' && isFinite(desvioRaw)) ? desvioRaw : null;
    if(desvio===null && status==='Concluído' && planEnd && realEnd){
      desvio = Math.round((new Date(realEnd+'T00:00:00') - new Date(planEnd+'T00:00:00'))/(1000*60*60*24));
    }

    const validadoRaw = (r['Validação']!==null && r['Validação']!==undefined) ? r['Validação'] : r['Validado'];
    const validado = (validadoRaw && validadoRaw!=='-') ? validadoRaw : (status!=='Concluído' ? 'Ag. Envio' : null);
    const depValeRaw = r['Dependêcia Vale'];
    const dep_vale = (depValeRaw && depValeRaw!=='-') ? depValeRaw : null;
    const depTenaxRaw = r['Dependêcia Tenax'];
    const dep_tenax = (depTenaxRaw && depTenaxRaw!=='-') ? depTenaxRaw : (status!=='Concluído' ? 'Pendente (Ag. Envio)' : null);

    recs.push({
      id: recs.length+1, pilar, sistema, ativo, floc, denom,
      plan_start: planStart || planEnd, plan_end: planEnd,
      real_start: realStart, real_end: realEnd, status,
      desvio, dep_vale, dep_tenax, validado,
      retorno_previsto: toISO(r['Retorno previsto']), retorno_real: toISO(r['Retorno real'])
    });
  });

  if(!recs.length) throw new Error('nenhum item de ' + AREA_LABEL[area].toUpperCase() + ' (3º nível ' + niveis3.join('/') + ') encontrado na aba "Priorização Vale" — confira se esta é a planilha do processo certo');
  areaItems[area] = recs;
  if(currentArea===area) items = recs;
  return recs.length;
}

function rebuildBritagemFromWorkbook(workbook){ return parsePriorizacaoVale(workbook, 'britagem'); }
function rebuildEnergiaFromWorkbook(workbook){ return parsePriorizacaoVale(workbook, 'energia'); }

// ---------- utilidades de data ----------
function parseDate(iso){ return iso ? new Date(iso+'T00:00:00') : null; }
function fmtDate(iso){ const d=parseDate(iso); return d ? d.toLocaleDateString('pt-BR') : '—'; }

function startDateOverall(){
  let min = null;
  items.forEach(i=>{
    const d = parseDate(i.plan_start);
    if(d && (!min || d<min)) min = d;
  });
  return min || new Date('2026-06-22T00:00:00');
}
function weekIndexOf(dateObj, start){
  const diffDays = Math.floor((dateObj - start)/(1000*60*60*24));
  return Math.floor(diffDays/7)+1;
}
function globalWeeksTotal(start){
  let maxW=1;
  items.forEach(i=>{
    const d = parseDate(i.plan_end);
    if(d){ const w = weekIndexOf(d,start); if(w>maxW) maxW=w; }
  });
  return maxW;
}
function currentWeek(start, weeksTotal){
  let w = weekIndexOf(new Date(), start);
  if(w<1) w=1;
  if(w>weeksTotal) w=weeksTotal;
  return w;
}

function pilarCounts(){
  const counts = {};
  PILAR_ORDER.forEach(p=>counts[p]={total:0,concl:0});
  items.forEach(i=>{
    if(!counts[i.pilar]) counts[i.pilar]={total:0,concl:0};
    counts[i.pilar].total++;
    if(i.status==='Concluído') counts[i.pilar].concl++;
  });
  return counts;
}

// curva planejada acumulada (%) por semana, para uma lista de pilares (combinados)
function pilarStartWeek(pilarList, start){
  let minDate = null;
  items.forEach(i=>{
    if(!pilarList.includes(i.pilar)) return;
    const d = parseDate(i.plan_start);
    if(d && (!minDate || d < minDate)) minDate = d;
  });
  if(!minDate) return 0;
  // weekIndexOf é 1-based (dia 0 = semana 1); convertemos para 0-based subtraindo 1
  return Math.max(0, weekIndexOf(minDate, start) - 1);
}

function plannedCumWeekly(pilarList, start, weeksTotal){
  const weekly = new Array(weeksTotal+1).fill(0);
  let total = 0;
  items.forEach(i=>{
    if(!pilarList.includes(i.pilar)) return;
    total++;
    const d = parseDate(i.plan_end);
    if(d){ const w=Math.max(1,Math.min(weeksTotal, weekIndexOf(d,start))); weekly[w]++; }
  });
  const cum = new Array(weeksTotal+1).fill(0);
  let acc=0;
  for(let w=1;w<=weeksTotal;w++){ acc+=weekly[w]; cum[w]=total? acc/total*100 : 0; }
  return {weekly, cum, total};
}

function realizedCumWeekly(pilarList, start, weeksTotal){
  const total = items.filter(i=>pilarList.includes(i.pilar)).length || 1;
  const weekly = new Array(weeksTotal+1).fill(0);
  items.forEach(i=>{
    if(!pilarList.includes(i.pilar)) return;
    if(i.status==='Concluído'){
      const d = parseDate(i.real_end) || parseDate(i.plan_end);
      if(d){ const w=Math.max(1,Math.min(weeksTotal, weekIndexOf(d,start))); weekly[w]++; }
    }
  });
  const cum = new Array(weeksTotal+1).fill(0);
  let acc=0;
  for(let w=1;w<=weeksTotal;w++){ acc+=weekly[w]; cum[w]=acc/total*100; }
  return cum;
}

// ---------- seletores de equipe ----------
function renderTeamSelect(containerId, selectedSet, onChange){
  const counts = pilarCounts();
  const el = document.getElementById(containerId);
  el.innerHTML = CHART_PILARES.map(p=>{
    const checked = selectedSet.has(p) ? 'checked' : '';
    const offClass = selectedSet.has(p) ? '' : 'off';
    const total = counts[p] ? counts[p].total : 0;
    return `<label class="team-chip ${offClass}" style="color:${PILAR_COLOR_HEX[p]};">
      <input type="checkbox" data-pilar="${p}" ${checked}>
      <span class="dot" style="background:${PILAR_COLOR_HEX[p]};"></span>${p} (${total})
    </label>`;
  }).join('') + `<div class="team-select-actions">
      <button class="btn-all">Todos</button>
      <button class="btn-none">Nenhum</button>
    </div>`;

  el.querySelectorAll('input[type=checkbox]').forEach(cb=>{
    cb.addEventListener('change', function(){
      const p = this.dataset.pilar;
      if(this.checked) selectedSet.add(p); else selectedSet.delete(p);
      this.closest('.team-chip').classList.toggle('off', !this.checked);
      onChange();
    });
  });
  el.querySelector('.btn-all').addEventListener('click', ()=>{
    CHART_PILARES.forEach(p=>selectedSet.add(p));
    renderTeamSelect(containerId, selectedSet, onChange);
    onChange();
  });
  el.querySelector('.btn-none').addEventListener('click', ()=>{
    selectedSet.clear();
    renderTeamSelect(containerId, selectedSet, onChange);
    onChange();
  });
}

// ---------- KPIs ----------
function renderKPIs(){
  const counts = pilarCounts();
  const total = items.length;
  const concl = items.filter(i=>i.status==='Concluído').length;
  const activePilares = PILAR_ORDER.filter(p=>counts[p] && counts[p].total>0).length;
  const start = startDateOverall();
  const weeksTotal = globalWeeksTotal(start);

  const totalSemInventario = total - (counts['Inventário'] ? counts['Inventário'].total : 0);
  const pct = total? (concl/total*100):0;
  const andamento = items.filter(i=>i.status==='Em andamento' || i.status==='Em execução').length;

  const cards = [
    {label:'Processos ativos', value: activePilares, sub: 'pilares com itens'},
    {label:'Horizonte', value: weeksTotal+' semanas', sub: 'do cronograma planejado'},
    {label:'Em andamento', value: andamento, sub: 'itens em execução agora'},
    {label:'Total geral', value: total, sub: 'inclui levantamento de Inventário'},
    {label:'Total sem Inventário', value: totalSemInventario, sub: 'total real (exclui levantamento)'},
    {label:'% concluído', value: pct.toFixed(1)+'%', sub: concl+' de '+total},
  ];
  document.getElementById('a_kpiRow').innerHTML = cards.map(c=>`
    <div class="kpi-card">
      <div class="kpi-label">${c.label}</div>
      <div class="kpi-value">${c.value}</div>
      <div class="kpi-sub">${c.sub}</div>
    </div>`).join('');
}

// ---------- curvas individuais ----------
function weeklyAvgDesvio(pilarList, start, weeksTotal){
  const sums = new Array(weeksTotal+1).fill(0);
  const counts = new Array(weeksTotal+1).fill(0);
  items.forEach(i=>{
    if(!pilarList.includes(i.pilar)) return;
    if(i.desvio===null || i.desvio===undefined) return;
    const d = parseDate(i.real_end);
    if(!d) return;
    const w = Math.max(0, Math.min(weeksTotal, weekIndexOf(d, start)));
    sums[w] += i.desvio;
    counts[w] += 1;
  });
  const avg = sums.map((s,w)=> counts[w] ? s/counts[w] : null);
  return {avg, counts};
}

function renderDesvioBarras(){
  if(desvioSubView==='atrasado'){ renderDesvioAtrasados(); return; }
  renderDesvioResumo();
}

function renderDesvioResumo(){
  const activeList = PILAR_ORDER.filter(p=>selectedIndividual.has(p));
  let bars = [];
  if(desvioViewMode==='pilar'){
    bars = activeList.map(p=>{
      const itemsP = items.filter(i=>i.pilar===p && i.desvio!==null && i.desvio!==undefined);
      const avg = itemsP.length ? itemsP.reduce((s,i)=>s+i.desvio,0)/itemsP.length : null;
      const adiantados = itemsP.filter(i=>i.desvio<0).length;
      const noPrazo = itemsP.filter(i=>i.desvio===0).length;
      const atrasados = itemsP.filter(i=>i.desvio>0).length;
      return {label:p, color:PILAR_COLOR_HEX[p], avg, count:itemsP.length, adiantados, noPrazo, atrasados};
    });
  } else {
    const itemsAll = items.filter(i=>activeList.includes(i.pilar) && i.desvio!==null && i.desvio!==undefined);
    const avg = itemsAll.length ? itemsAll.reduce((s,i)=>s+i.desvio,0)/itemsAll.length : null;
    const adiantados = itemsAll.filter(i=>i.desvio<0).length;
    const noPrazo = itemsAll.filter(i=>i.desvio===0).length;
    const atrasados = itemsAll.filter(i=>i.desvio>0).length;
    bars = [{label:'Geral (equipes selecionadas)', color:'#045552', avg, count:itemsAll.length, adiantados, noPrazo, atrasados}];
  }

  const el = document.getElementById('a_desvioBarras');
  if(bars.length===0){
    el.innerHTML = '<div class="dep-empty">Nenhuma equipe selecionada</div>';
    return;
  }

  const valuesValid = bars.filter(b=>b.avg!==null).map(b=>Math.abs(b.avg));
  const maxAbs = valuesValid.length ? Math.max(1, ...valuesValid) : 1;

  el.innerHTML = bars.map(b=>{
    if(b.avg===null){
      return `<div class="diverge-row">
        <span class="diverge-label" style="color:${b.color};">${b.label}</span>
        <div class="diverge-track"><div class="diverge-center"></div></div>
        <span class="diverge-value" style="color:var(--muted);">sem dados</span>
      </div>`;
    }
    const isAhead = b.avg < 0;   // desvio negativo = adiantado; positivo = atrasado
    const color = isAhead ? '#16A34A' : (b.avg>0 ? '#DC2626' : '#8A95A3');
    const pct = Math.min(50, Math.abs(b.avg)/maxAbs*50);
    const barStyle = isAhead
      ? `left:${50-pct}%;width:${pct}%;`
      : `left:50%;width:${pct}%;`;
    const valueLabel = `${b.avg>0?'+':''}${b.avg.toFixed(1)}d`;
    const stateLabel = isAhead ? 'adiantado em média' : (b.avg>0 ? 'atrasado em média' : 'no prazo em média');

    const total = b.count || 1;
    const segOrder = [
      {key:'adiantados', label:'Adiantado', color:'#16A34A'},
      {key:'noPrazo',     label:'No prazo',  color:'#8A95A3'},
      {key:'atrasados',   label:'Atrasado',  color:'#DC2626'},
    ];
    const breakdownSegs = segOrder.map(s=>{
      const w = b[s.key]/total*100;
      if(w<=0) return '';
      return `<div title="${s.label}: ${b[s.key]}" style="width:${w}%;background:${s.color};height:100%;"></div>`;
    }).join('');
    const breakdownLegend = segOrder.map(s=>
      `<span style="color:${s.color};"><span class="dot" style="background:${s.color};"></span>${b[s.key]} ${s.label.toLowerCase()}</span>`
    ).join('');

    return `<div class="diverge-row">
      <span class="diverge-label" style="color:${b.color};"><span class="dot" style="background:${b.color};"></span>${b.label}</span>
      <div class="diverge-track">
        <div class="diverge-center"></div>
        <div class="diverge-bar" style="${barStyle}background:${color};"></div>
      </div>
      <span class="diverge-value" style="color:${color};">${valueLabel} <span class="diverge-state">${stateLabel}</span></span>
    </div>
    <div class="breakdown-wrap">
      <div class="breakdown-track">${breakdownSegs}</div>
      <div class="breakdown-legend">${breakdownLegend}<span class="breakdown-total">${b.count} ${b.count===1?'item concluído':'itens concluídos'} com desvio registrado</span></div>
    </div>`;
  }).join('');
}

function renderDesvioAtrasados(){
  const activeList = PILAR_ORDER.filter(p=>selectedIndividual.has(p));
  const CAUSE_COLORS = {'Tenax':'#7C3AED','Vale':'#00B0CA','Não classificado':'#98A2B3'};
  const CAUSE_ORDER = ['Tenax','Vale','Não classificado'];

  function buildGroup(label, color, pilarFilter){
    const atrasados = items.filter(i=>pilarFilter(i.pilar) && i.desvio!==null && i.desvio!==undefined && i.desvio>0);
    const counts = {'Tenax':0,'Vale':0,'Não classificado':0};
    atrasados.forEach(i=>{
      const cause = classifyDelayCause(i) || 'Não classificado';
      counts[cause]++;
    });
    return {label, color, total: atrasados.length, counts};
  }

  let groups = [];
  if(desvioViewMode==='pilar'){
    groups = activeList.map(p=> buildGroup(p, PILAR_COLOR_HEX[p], pl=>pl===p));
  } else {
    groups = [ buildGroup('Geral (equipes selecionadas)', '#045552', pl=>activeList.includes(pl)) ];
  }

  const el = document.getElementById('a_desvioBarras');
  if(groups.length===0){
    el.innerHTML = '<div class="dep-empty">Nenhuma equipe selecionada</div>';
    return;
  }

  el.innerHTML = groups.map(g=>{
    if(g.total===0){
      return `<div class="diverge-row">
        <span class="diverge-label" style="color:${g.color};"><span class="dot" style="background:${g.color};"></span>${g.label}</span>
        <div class="diverge-track"><div class="diverge-center"></div></div>
        <span class="diverge-value" style="color:var(--muted);">sem atrasos</span>
      </div>`;
    }
    const segs = CAUSE_ORDER.map(k=>{
      const w = g.counts[k]/g.total*100;
      if(w<=0) return '';
      return `<div title="${k}: ${g.counts[k]}" style="width:${w}%;background:${CAUSE_COLORS[k]};height:100%;"></div>`;
    }).join('');
    const legend = CAUSE_ORDER.map(k=>
      `<span style="color:${CAUSE_COLORS[k]};"><span class="dot" style="background:${CAUSE_COLORS[k]};"></span>${g.counts[k]} ${k.toLowerCase()}</span>`
    ).join('');
    return `<div class="diverge-row">
      <span class="diverge-label" style="color:${g.color};"><span class="dot" style="background:${g.color};"></span>${g.label}</span>
      <span class="diverge-value" style="color:var(--muted);width:auto;flex:1;text-align:left;">${g.total} ${g.total===1?'item atrasado':'itens atrasados'}</span>
    </div>
    <div class="breakdown-wrap">
      <div class="breakdown-track">${segs}</div>
      <div class="breakdown-legend">${legend}</div>
    </div>`;
  }).join('');
}



function renderCurvaIndividual(){
  const start = startDateOverall();
  const weeksTotal = globalWeeksTotal(start);
  const activeList = PILAR_ORDER.filter(p=>selectedIndividual.has(p));

  // ----- legenda dinâmica -----
  const GERAL_COLOR = '#2563EB';
  let legendItems = [];
  if(individualViewMode==='geral'){
    legendItems = [`<span style="color:${GERAL_COLOR};"><span class="dot" style="background:${GERAL_COLOR};"></span>Geral (todos os pilares selecionados)</span>`];
  } else {
    legendItems = activeList.length
      ? activeList.map(p=>`<span style="color:${PILAR_COLOR_HEX[p]};"><span class="dot" style="background:${PILAR_COLOR_HEX[p]};"></span>${p}</span>`)
      : [`<span style="color:var(--muted);">Nenhuma equipe selecionada</span>`];
  }
  ['a_legendIndividual','a_legendIndividual_fs'].forEach(id=>{
    const el=document.getElementById(id); if(el) el.innerHTML=legendItems.join('');
  });

  const W=900,H=340,padL=46,padR=20,padT=20,padB=40;
  const plotW=W-padL-padR, plotH=H-padT-padB;
  function xPos(w){ return padL + (w/weeksTotal)*plotW; }
  function yPos(v){ return padT + plotH - (v/100)*plotH; }

  let svg='';
  svg += `<line x1="${padL}" y1="${padT}" x2="${padL}" y2="${H-padB}" stroke="${CHART_THEME.axisLine}"/>`;
  svg += `<line x1="${padL}" y1="${H-padB}" x2="${W-padR}" y2="${H-padB}" stroke="${CHART_THEME.axisLine}"/>`;
  [0,10,20,30,40,50,60,70,80,90,100].forEach(v=>{
    const y=yPos(v);
    svg += `<line x1="${padL}" y1="${y}" x2="${W-padR}" y2="${y}" stroke="${CHART_THEME.gridLine}"/>`;
    svg += `<text x="${padL-8}" y="${y+4}" font-size="10" fill="${CHART_THEME.axisText}" text-anchor="end">${v}%</text>`;
  });
  const step = Math.max(1, Math.ceil(weeksTotal/20));
  for(let w=0; w<=weeksTotal; w+=step){
    svg += `<text x="${xPos(w)}" y="${H-padB+16}" font-size="9.5" fill="${CHART_THEME.axisText}" text-anchor="middle">S${w}</text>`;
  }

  if(individualViewMode==='geral'){
    const {cum} = plannedCumWeekly(activeList, start, weeksTotal);
    const sw = pilarStartWeek(activeList, start);
    let d=''; let first=true;
    for(let w=sw; w<=weeksTotal; w++){ d+=(first?'M':'L')+xPos(w)+','+yPos(cum[w]||0)+' '; first=false; }
    if(d){
      svg += `<path d="${d}" fill="none" stroke="${GERAL_COLOR}" stroke-width="2.5"/>`;
      for(let w=sw; w<=weeksTotal; w++) svg+=`<circle cx="${xPos(w)}" cy="${yPos(cum[w]||0)}" r="3" fill="${GERAL_COLOR}"/>`;
    }
  } else {
    activeList.forEach(p=>{
      const {cum} = plannedCumWeekly([p], start, weeksTotal);
      const sw = pilarStartWeek([p], start);
      let d=''; let first=true;
      for(let w=sw; w<=weeksTotal; w++){ d+=(first?'M':'L')+xPos(w)+','+yPos(cum[w]||0)+' '; first=false; }
      if(d){
        svg += `<path d="${d}" fill="none" stroke="${PILAR_COLOR_HEX[p]}" stroke-width="2.5"/>`;
        for(let w=sw; w<=weeksTotal; w++) svg+=`<circle cx="${xPos(w)}" cy="${yPos(cum[w]||0)}" r="3" fill="${PILAR_COLOR_HEX[p]}"/>`;
      }
    });
  }

  ['a_curvaIndividualSvg','a_curvaIndividualSvg_fs'].forEach(id=>{
    const el=document.getElementById(id); if(el) el.innerHTML=svg;
  });
  renderDesvioBarras();
}



// ---------- curva consolidada ----------
function fridayOfCurrentWeek(){
  const today = new Date();
  today.setHours(0,0,0,0);
  const dow = today.getDay(); // 0=Dom..6=Sáb
  const isoDow = dow===0 ? 7 : dow; // 1=Seg..7=Dom
  const diff = 5 - isoDow; // dias até a sexta-feira da mesma semana (pode ser negativo)
  const friday = new Date(today);
  friday.setDate(today.getDate()+diff);
  return friday;
}
function formatDateBR(d){
  const dd = String(d.getDate()).padStart(2,'0');
  const mm = String(d.getMonth()+1).padStart(2,'0');
  return `${dd}/${mm}`;
}

function renderCurvaConsolidada(){
  const start = startDateOverall();
  const startTs = start.getTime();
  const weeksTotal = globalWeeksTotal(start);
  const activeList = CHART_PILARES.filter(p=>selectedConsolidada.has(p));

  const today = new Date(); today.setHours(0,0,0,0);
  const todayTs = today.getTime();
  const todayLabel = formatDateBR(today);

  if(activeList.length===0){
    ['a_curvaConsSub','a_legendConsolidada','a_legendConsolidada_fs'].forEach(id=>{
      const el=document.getElementById(id); if(el) el.innerHTML='';
    });
    document.getElementById('a_curvaConsSub').textContent='Nenhuma equipe selecionada';
    ['a_curvaConsSvg','a_curvaConsSvg_fs'].forEach(id=>{const el=document.getElementById(id);if(el)el.innerHTML='';});
    return;
  }

  const realColor = '#E67E22';
  const planColor = activeList.length===1 ? PILAR_COLOR_HEX[activeList[0]] : '#007E7A';

  const legendHTML = `
    <span style="color:${planColor};"><i class="dash-line" style="border-color:${planColor};"></i> Planejado${activeList.length===1?' ('+activeList[0]+')':' (consolidado)'}</span>
    <span style="color:${realColor};"><i class="solid-line" style="background:${realColor};"></i> Realizado</span>`;
  ['a_legendConsolidada','a_legendConsolidada_fs'].forEach(id=>{
    const el=document.getElementById(id); if(el) el.innerHTML=legendHTML;
  });

  const planned = plannedCumWeekly(activeList, start, weeksTotal);
  const totalItems = items.filter(i=>activeList.includes(i.pilar)).length;
  const consStartWeek = pilarStartWeek(activeList, start);

  // ----- Realized: posicionamento exato por dia -----
  const byDayMap = new Map();
  items.forEach(i=>{
    if(!activeList.includes(i.pilar)||i.status!=='Concluído') return;
    const d = parseDate(i.real_end)||parseDate(i.plan_end);
    if(!d) return;
    const dayKey = Math.floor(d.getTime()/(24*3600*1000));
    byDayMap.set(dayKey, (byDayMap.get(dayKey)||0)+1);
  });
  const sortedDays = Array.from(byDayMap.keys()).sort((a,b)=>a-b);
  let cumAcc=0;
  const realPoints = [];
  sortedDays.forEach(day=>{
    cumAcc += byDayMap.get(day);
    realPoints.push({ ts: day*24*3600*1000, count: cumAcc, pct: cumAcc/totalItems*100 });
  });

  const pastPoints   = realPoints.filter(p=>p.ts<=todayTs);
  const futurePoints = realPoints.filter(p=>p.ts>todayTs);
  const lastPoint    = realPoints.length ? realPoints[realPoints.length-1] : null;
  const currentReal  = pastPoints.length ? pastPoints[pastPoints.length-1] : {count:0, pct:0};

  document.getElementById('a_curvaConsSub').textContent =
    `Planejado e realizado: ${activeList.join(', ')} · hoje ${todayLabel} · ${currentReal.count} de ${totalItems} itens concluídos`
    + (futurePoints.length ? ` · ${lastPoint.count} já registrados além de hoje` : '');

  const W=1180,H=500,padL=56,padR=30,padT=40,padB=76;
  const plotW=W-padL-padR, plotH=H-padT-padB;

  // Helper: data → x exato (em fração de semanas)
  function xPosDate(ts){ return padL + ((ts - startTs)/(7*24*3600*1000)/weeksTotal)*plotW; }
  function xPos(w){ return padL + (w/weeksTotal)*plotW; }
  function yPos(v){ return padT + plotH - (v/100)*plotH; }
  function weekStartDate(w){ const d=new Date(start); d.setDate(d.getDate()+w*7); return d; }

  let svg='';
  svg+=`<line x1="${padL}" y1="${padT}" x2="${padL}" y2="${H-padB}" stroke="${CHART_THEME.axisLine}"/>`;
  svg+=`<line x1="${padL}" y1="${H-padB}" x2="${W-padR}" y2="${H-padB}" stroke="${CHART_THEME.axisLine}"/>`;

  // Grade horizontal
  [0,10,20,30,40,50,60,70,80,90,100].forEach(v=>{
    const y=yPos(v);
    svg+=`<line x1="${padL}" y1="${y}" x2="${W-padR}" y2="${y}" stroke="${CHART_THEME.gridLine}"/>`;
    svg+=`<text x="${padL-10}" y="${y+4}" font-size="12" fill="${CHART_THEME.axisText}" text-anchor="end">${v}%</text>`;
  });

  // Eixo X: semanas + data + linhas de dia entre semanas
  for(let w=0;w<=weeksTotal;w++){
    const xp=xPos(w);
    const wd=weekStartDate(w);
    const dl=`${String(wd.getDate()).padStart(2,'0')}/${String(wd.getMonth()+1).padStart(2,'0')}`;
    svg+=`<line x1="${xp}" y1="${padT}" x2="${xp}" y2="${H-padB}" stroke="${CHART_THEME.gridLine}" stroke-opacity="0.5"/>`;
    svg+=`<text x="${xp}" y="${H-padB+18}" font-size="11" fill="${CHART_THEME.axisText}" text-anchor="middle">S${w}</text>`;
    svg+=`<text x="${xp}" y="${H-padB+34}" font-size="10" fill="${CHART_THEME.axisText}" text-anchor="middle" opacity="0.7">${dl}</text>`;
    if(w<weeksTotal){
      for(let d=1;d<=6;d++){
        const dd=new Date(wd); dd.setDate(wd.getDate()+d);
        const xd=xPosDate(dd.getTime());
        svg+=`<line x1="${xd}" y1="${padT}" x2="${xd}" y2="${H-padB}" stroke="${CHART_THEME.gridLineLight}" stroke-opacity="0.35"/>`;
      if(d===2||d===4){
          // datas intermediárias removidas — apenas linhas de guia
        }
      }
    }
  }

  // Marcador HOJE
  const todayX = xPosDate(todayTs);
  svg+=`<line x1="${todayX}" y1="${padT}" x2="${todayX}" y2="${H-padB}" stroke="${realColor}" stroke-width="1.5" stroke-dasharray="3,3" opacity="0.7"/>`;
  svg+=`<text x="${todayX}" y="${padT-8}" font-size="11" fill="${realColor}" text-anchor="middle" font-weight="700">Hoje ${todayLabel}</text>`;

  // Linha Planejado (tracejada) — rótulos só a cada 2 semanas para reduzir poluição
  let dPlan=''; let planFirst=true;
  for(let w=consStartWeek;w<=weeksTotal;w++){
    dPlan+=(planFirst?'M':'L')+xPos(w)+','+yPos(planned.cum[w]||0)+' '; planFirst=false;
  }
  svg+=`<path d="${dPlan}" fill="none" stroke="${planColor}" stroke-width="1.75" stroke-dasharray="7,5"/>`;
  for(let w=consStartWeek;w<=weeksTotal;w++){
    const showLabel = (w===consStartWeek || w===weeksTotal || (w-consStartWeek)%2===0);
    svg+=`<circle cx="${xPos(w)}" cy="${yPos(planned.cum[w]||0)}" r="2.5" fill="${planColor}"/>`;
    if(showLabel) svg+=`<text x="${xPos(w)}" y="${yPos(planned.cum[w]||0)-9}" font-size="9.5" fill="${planColor}" text-anchor="middle">${Math.round(planned.cum[w]||0)}%</text>`;
  }

  // Linha Realizado PASSADO (até hoje) — exato por data, label apenas no ponto final
  if(pastPoints.length){
    const firstRealX = xPosDate(pastPoints[0].ts);
    const originX = Math.min(firstRealX, xPos(consStartWeek));
    let dReal=`M${originX},${yPos(0)} `;
    pastPoints.forEach(p=>{ dReal+=`L${xPosDate(p.ts)},${yPos(p.pct)} `; });
    svg+=`<path d="${dReal}" fill="none" stroke="${realColor}" stroke-width="2.25"/>`;
    pastPoints.forEach((p,idx)=>{
      const px=xPosDate(p.ts), py=yPos(p.pct);
      const isLast = idx===pastPoints.length-1;
      svg+=`<circle cx="${px}" cy="${py}" r="${isLast?5:3}" fill="${realColor}" stroke="#fff" stroke-width="1.5"/>`;
      if(isLast){
        svg+=`<text x="${px}" y="${py-14}" font-size="12" fill="${realColor}" text-anchor="middle" font-weight="700">${p.count}</text>`;
      }
    });
    // Linha vertical discreta no último ponto
    const lastPast = pastPoints[pastPoints.length-1];
    const lastPastX = xPosDate(lastPast.ts);
    svg+=`<line x1="${lastPastX}" y1="${padT}" x2="${lastPastX}" y2="${H-padB}" stroke="${realColor}" stroke-width="1" stroke-dasharray="4,4" opacity="0.35"/>`;
  }

  // Linha Realizado FUTURO — continuação além de hoje, label apenas no ponto final
  if(futurePoints.length){
    const futColor = '#C0682A';
    const anchor = pastPoints.length ? pastPoints[pastPoints.length-1] : {ts:todayTs, pct:0};
    let dFut=`M${xPosDate(anchor.ts)},${yPos(anchor.pct)} `;
    futurePoints.forEach(p=>{ dFut+=`L${xPosDate(p.ts)},${yPos(p.pct)} `; });
    svg+=`<path d="${dFut}" fill="none" stroke="${futColor}" stroke-width="2" stroke-dasharray="5,3"/>`;
    futurePoints.forEach((p,idx)=>{
      const px=xPosDate(p.ts), py=yPos(p.pct);
      const isLast = idx===futurePoints.length-1;
      svg+=`<circle cx="${px}" cy="${py}" r="${isLast?5:3}" fill="${futColor}" stroke="#fff" stroke-width="1.5"/>`;
      if(isLast){
        svg+=`<text x="${px}" y="${py-14}" font-size="12" fill="${futColor}" text-anchor="middle" font-weight="700">${p.count}</text>`;
      }
    });
    const lastX=xPosDate(lastPoint.ts);
    svg+=`<line x1="${lastX}" y1="${padT}" x2="${lastX}" y2="${H-padB}" stroke="${futColor}" stroke-width="1" stroke-dasharray="4,4" opacity="0.35"/>`;
  }

  ['a_curvaConsSvg','a_curvaConsSvg_fs'].forEach(id=>{
    const el=document.getElementById(id); if(el) el.innerHTML=svg;
  });
}


// ---------- avanço por pilar ----------
function renderPilarBars(){
  const counts = pilarCounts();
  document.getElementById('a_pilarBars').innerHTML = CHART_PILARES.map(p=>{
    const c = counts[p] || {total:0,concl:0};
    const pct = c.total? (c.concl/c.total*100):0;
    return `<div class="pilar-row">
      <div class="pilar-top">
        <span class="pilar-name"><span class="swatch" style="background:${PILAR_COLOR_HEX[p]};"></span>${p}</span>
        <span style="color:var(--muted);">${c.concl}/${c.total} · ${pct.toFixed(0)}%</span>
      </div>
      <div class="bar-bg"><div class="bar-fill" style="width:${pct}%;background:${PILAR_COLOR_HEX[p]};"></div></div>
    </div>`;
  }).join('');
}

// ---------- mapa de entregas (heatmap) ----------
function periodLabel(gran, idx, start){
  if(gran==='semana') return 'S'+idx;
  if(gran==='mes'){
    const d = new Date(start.getTime()); d.setMonth(d.getMonth()+idx);
    return d.toLocaleDateString('pt-BR',{month:'short',year:'2-digit'}).replace('.','');
  }
  const d = new Date(start.getTime()); d.setFullYear(d.getFullYear()+idx);
  return d.getFullYear();
}
function periodIndexFor(date, gran, start){
  if(gran==='semana') return Math.floor((date-start)/(1000*60*60*24*7));
  if(gran==='mes') return (date.getFullYear()-start.getFullYear())*12 + (date.getMonth()-start.getMonth());
  return date.getFullYear()-start.getFullYear();
}
let fluxoViewMode = 'geral'; // 'geral' | 'pilar'
let fluxoPilar = null;       // pilar selecionado quando fluxoViewMode==='pilar'

function sistemaCounts(pilarFilter){
  const counts = {};
  Object.keys(SISTEMA_META).forEach(k=>counts[k]={total:0,concl:0,andamento:0});
  items.forEach(i=>{
    // casa o sistema de forma tolerante (maiúsculas/espaços) e cai para o código do ativo se preciso
    let s = i.sistema ? String(i.sistema).trim().toUpperCase() : null;
    if(!s || !counts[s]) s = sistemaFromAtivo(i.ativo);
    if(!s || !counts[s]) return;
    if(pilarFilter && i.pilar!==pilarFilter) return;
    counts[s].total++;
    if(i.status==='Concluído') counts[s].concl++;
    else if(i.status==='Em andamento' || i.status==='Em execução') counts[s].andamento++;
  });
  return counts;
}

function renderFluxoBlocos(){
  if(currentArea==='energia'){ renderFluxoBlocosEnergia(); return; }
  const counts = sistemaCounts(fluxoViewMode==='pilar' ? fluxoPilar : null);
  const W=1180, H=460;
  const BW=190, BH=80, AW=190, AH=64;

  // posições fixas das caixas principais (fluxo da esquerda para a direita)
  const pos = {
    BRT01: {x:40,  y:70},
    EST01: {x:300, y:70},
    BRT02: {x:570, y:20},
    BRT03: {x:570, y:128},
    BRT04: {x:840, y:70},
  };
  const auxPos = {
    EQA01: {x:40,  y:280},
    EQA03: {x:300, y:280},
    DRN01: {x:570, y:280},
    EQA02: {x:840, y:280},
    EDF01: {x:1040,y:280, w:100},
  };

  function box(code, x, y, w, h, dashed){
    const meta = SISTEMA_META[code];
    const c = counts[code] || {total:0,concl:0,andamento:0};
    const pct = c.total ? Math.round(c.concl/c.total*100) : 0;
    const pctAnd = c.total ? (c.andamento/c.total*100) : 0;
    const strokeStyle = dashed ? `stroke-dasharray="4,3"` : '';
    const labelY = y+22, subY = y+38, statY = y+56, barY = y+64;
    let s = '';
    s += `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" fill="${CHART_THEME.cardBg}" stroke="${meta.color}" stroke-width="1.4" ${strokeStyle}/>`;
    s += `<text x="${x+12}" y="${y+16}" font-size="12.5" font-weight="700" fill="${meta.color}">${code}</text>`;
    s += `<text x="${x+12}" y="${labelY+4}" font-size="11" font-weight="600" fill="${CHART_THEME.darkText}">${meta.label}</text>`;
    s += `<text x="${x+12}" y="${subY+2}" font-size="9.5" fill="${CHART_THEME.mutedText}">${meta.sub}</text>`;
    if(h >= 64){
      const andTxt = c.andamento ? ` · ${c.andamento} em and.` : '';
      s += `<text x="${x+12}" y="${statY}" font-size="10" fill="${CHART_THEME.axisText}">${c.concl}/${c.total} itens · ${pct}%${andTxt}</text>`;
      const barW = w-24;
      s += `<rect x="${x+12}" y="${barY}" width="${barW}" height="5" rx="2.5" fill="${CHART_THEME.gridLine}"/>`;
      if(pctAnd>0) s += `<rect x="${x+12+barW*pct/100}" y="${barY}" width="${Math.min(barW*pctAnd/100, barW-barW*pct/100)}" height="5" rx="2.5" fill="${meta.color}" opacity="0.35"/>`;
      s += `<rect x="${x+12}" y="${barY}" width="${barW*pct/100}" height="5" rx="2.5" fill="${meta.color}"/>`;
    }
    return s;
  }

  function arrow(x1,y1,x2,y2,color){
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color||CHART_THEME.axisLine}" stroke-width="1.6" marker-end="url(#fluxoArrow)"/>`;
  }
  function elbow(x1,y1,x2,y2,xmid,color){
    return `<path d="M${x1},${y1} L${xmid},${y1} L${xmid},${y2} L${x2},${y2}" fill="none" stroke="${color||CHART_THEME.axisLine}" stroke-width="1.6" marker-end="url(#fluxoArrow)"/>`;
  }
  function dashedLink(x1,y1,x2,y2){
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${CHART_THEME.axisLine}" stroke-width="1" stroke-dasharray="3,3" opacity="0.6"/>`;
  }

  let svg = `<defs><marker id="fluxoArrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
    <path d="M1,1 L9,5 L1,9 Z" fill="${CHART_THEME.axisText}"/></marker></defs>`;

  // título de seção do fluxo principal
  svg += `<text x="40" y="-8" font-size="11" font-weight="700" fill="${CHART_THEME.mutedText}" letter-spacing="0.5">FLUXO PRINCIPAL DO PROCESSO</text>`;

  // ---- entrada do processo: alimentação da britagem ----
  svg += `<text x="${pos.BRT01.x+BW/2}" y="55" font-size="9.5" fill="${CHART_THEME.mutedText}" text-anchor="middle">Alimentação da britagem</text>`;
  svg += arrow(pos.BRT01.x+BW/2, 60, pos.BRT01.x+BW/2, pos.BRT01.y, '#007E7A');

  // ---- conexões do fluxo principal ----
  svg += arrow(pos.BRT01.x+BW, pos.BRT01.y+BH/2, pos.EST01.x, pos.EST01.y+BH/2, '#007E7A');
  svg += elbow(pos.EST01.x+BW, pos.EST01.y+BH/2, pos.BRT02.x, pos.BRT02.y+BH/2, pos.EST01.x+BW+30, '#00B0CA');
  svg += elbow(pos.EST01.x+BW, pos.EST01.y+BH/2, pos.BRT03.x, pos.BRT03.y+BH/2, pos.EST01.x+BW+30, '#00B0CA');
  svg += elbow(pos.BRT02.x+BW, pos.BRT02.y+BH/2, pos.BRT04.x, pos.BRT04.y+BH/2, pos.BRT02.x+BW+30, '#0F6E56');
  svg += elbow(pos.BRT03.x+BW, pos.BRT03.y+BH/2, pos.BRT04.x, pos.BRT04.y+BH/2, pos.BRT03.x+BW+30, '#0F6E56');
  svg += arrow(pos.BRT04.x+BW, pos.BRT04.y+BH/2, W-20, pos.BRT04.y+BH/2, '#045552');
  svg += `<text x="${pos.BRT04.x+BW+18}" y="${pos.BRT04.y+BH/2-8}" font-size="9.5" font-weight="700" fill="${CHART_THEME.mutedText}">TCLD</text>`;

  // ---- caixas principais ----
  Object.keys(pos).forEach(code=>{ svg += box(code, pos[code].x, pos[code].y, BW, BH, false); });

  // ---- linha divisória entre fluxo principal e sistemas de apoio ----
  svg += `<line x1="20" y1="245" x2="${W-20}" y2="245" stroke="${CHART_THEME.gridLine}" stroke-dasharray="2,3"/>`;
  svg += `<text x="40" y="265" font-size="11" font-weight="700" fill="${CHART_THEME.mutedText}" letter-spacing="0.5">SISTEMAS DE APOIO</text>`;

  // ---- links tracejados para caixas de apoio ----
  svg += dashedLink(pos.BRT01.x+BW/2, pos.BRT01.y+BH, auxPos.EQA01.x+BW/2, auxPos.EQA01.y);
  svg += dashedLink(pos.EST01.x+BW/2, pos.EST01.y+BH, auxPos.EQA03.x+BW/2, auxPos.EQA03.y);
  svg += dashedLink((pos.BRT02.x+pos.BRT03.x)/2+BW/2, 245, auxPos.DRN01.x+BW/2, auxPos.DRN01.y);
  svg += dashedLink(pos.BRT04.x+BW/2, pos.BRT04.y+BH, auxPos.EQA02.x+BW/2, auxPos.EQA02.y);
  svg += dashedLink(auxPos.EQA02.x+BW, auxPos.EQA02.y+AH/2, auxPos.EDF01.x, auxPos.EDF01.y+AH/2);

  // ---- caixas de apoio ----
  svg += box('EQA01', auxPos.EQA01.x, auxPos.EQA01.y, AW, AH, true);
  svg += box('EQA03', auxPos.EQA03.x, auxPos.EQA03.y, AW, AH, true);
  svg += box('DRN01', auxPos.DRN01.x, auxPos.DRN01.y, AW, AH, true);
  svg += box('EQA02', auxPos.EQA02.x, auxPos.EQA02.y, AW, AH, true);
  svg += box('EDF01', auxPos.EDF01.x, auxPos.EDF01.y, auxPos.EDF01.w, AH, true);

  // ---- barra horizontal resumo: concluído + em andamento x total (todo o fluxograma) ----
  let totalAll=0, totalConcl=0, totalAnd=0;
  Object.keys(SISTEMA_META).forEach(k=>{ const c=counts[k]||{total:0,concl:0,andamento:0}; totalAll+=c.total; totalConcl+=c.concl; totalAnd+=(c.andamento||0); });
  const summaryPct = totalAll ? (totalConcl/totalAll*100) : 0;
  const summaryPctAnd = totalAll ? (totalAnd/totalAll*100) : 0;
  const sumX = 40, sumW = W-80;
  const dividerY = auxPos.EQA01.y + AH + 34;
  const labelY = dividerY + 18;
  const barY = labelY + 14;
  svg += `<line x1="${sumX}" y1="${dividerY}" x2="${sumX+sumW}" y2="${dividerY}" stroke="${CHART_THEME.gridLine}"/>`;
  svg += `<text x="${sumX}" y="${labelY}" font-size="10" fill="${CHART_THEME.mutedText}">Concluído no fluxo${fluxoViewMode==='pilar' && fluxoPilar ? ' · '+fluxoPilar : ' (geral)'}</text>`;
  svg += `<text x="${sumX+sumW}" y="${labelY}" font-size="10" fill="${CHART_THEME.mutedText}" text-anchor="end">${totalConcl} concluídos${totalAnd? ' + '+totalAnd+' em andamento':''} de ${totalAll} itens · ${summaryPct.toFixed(0)}%</text>`;
  svg += `<rect x="${sumX}" y="${barY}" width="${sumW}" height="3" rx="1.5" fill="${CHART_THEME.gridLine}"/>`;
  if(summaryPctAnd>0) svg += `<rect x="${sumX+sumW*summaryPct/100}" y="${barY}" width="${Math.min(sumW*summaryPctAnd/100, sumW-sumW*summaryPct/100)}" height="3" rx="1.5" fill="#045552" opacity="0.35"/>`;
  svg += `<rect x="${sumX}" y="${barY}" width="${sumW*summaryPct/100}" height="3" rx="1.5" fill="#045552"/>`;
  svg += `<circle cx="${sumX+sumW*summaryPct/100}" cy="${barY+1.5}" r="3.5" fill="#045552"/>`;

  const fullSvg = `<g transform="translate(0,28)">${svg}</g>`;
  ['a_fluxoSvg','a_fluxoSvg_fs'].forEach(id=>{
    const el = document.getElementById(id);
    if(!el) return;
    el.setAttribute('viewBox','0 0 1180 460');
    if(id==='a_fluxoSvg') el.style.height = '460px';
    el.innerHTML = fullSvg;
  });
}

// ---------- fluxograma de blocos — DISTRIBUIÇÃO DE ENERGIA ----------
function renderFluxoBlocosEnergia(){
  const counts = sistemaCounts(fluxoViewMode==='pilar' ? fluxoPilar : null);
  const W=1180;
  const BW=220, BH=80;   // caixas do fluxo principal
  const GW=210, GH=80;   // caixas da grade de subestações
  const AW=125, AH=64;   // caixas de apoio (DST02..DST09)

  function box(code, x, y, w, h, dashed){
    const meta = SISTEMA_META[code];
    const c = counts[code] || {total:0,concl:0,andamento:0};
    const pct = c.total ? Math.round(c.concl/c.total*100) : 0;
    const pctAnd = c.total ? (c.andamento/c.total*100) : 0;
    const strokeStyle = dashed ? `stroke-dasharray="4,3"` : '';
    const labelY = y+22, subY = y+38, statY = y+56, barY = y+64;
    let s = '';
    s += `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" fill="${CHART_THEME.cardBg}" stroke="${meta.color}" stroke-width="1.4" ${strokeStyle}/>`;
    s += `<text x="${x+12}" y="${y+16}" font-size="12.5" font-weight="700" fill="${meta.color}">${code}</text>`;
    s += `<text x="${x+12}" y="${labelY+4}" font-size="11" font-weight="600" fill="${CHART_THEME.darkText}">${meta.label}</text>`;
    s += `<text x="${x+12}" y="${subY+2}" font-size="9.5" fill="${CHART_THEME.mutedText}">${meta.sub}</text>`;
    if(h >= 64){
      const andTxt = c.andamento ? ` · ${c.andamento} em and.` : '';
      s += `<text x="${x+12}" y="${statY}" font-size="10" fill="${CHART_THEME.axisText}">${c.concl}/${c.total} itens · ${pct}%${andTxt}</text>`;
      const barW = w-24;
      s += `<rect x="${x+12}" y="${barY}" width="${barW}" height="5" rx="2.5" fill="${CHART_THEME.gridLine}"/>`;
      if(pctAnd>0) s += `<rect x="${x+12+barW*pct/100}" y="${barY}" width="${Math.min(barW*pctAnd/100, barW-barW*pct/100)}" height="5" rx="2.5" fill="${meta.color}" opacity="0.35"/>`;
      s += `<rect x="${x+12}" y="${barY}" width="${barW*pct/100}" height="5" rx="2.5" fill="${meta.color}"/>`;
    }
    return s;
  }
  function arrow(x1,y1,x2,y2,color){
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color||CHART_THEME.axisLine}" stroke-width="1.6" marker-end="url(#fluxoArrowE)"/>`;
  }

  let svg = `<defs><marker id="fluxoArrowE" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
    <path d="M1,1 L9,5 L1,9 Z" fill="${CHART_THEME.axisText}"/></marker></defs>`;

  // ---- fluxo principal: LTR01 -> SUB01 -> DST01 ----
  svg += `<text x="40" y="-8" font-size="11" font-weight="700" fill="${CHART_THEME.mutedText}" letter-spacing="0.5">FLUXO PRINCIPAL — TRANSMISSÃO E DISTRIBUIÇÃO</text>`;
  const mainY = 30;
  const mainPos = { LTR01:{x:40}, SUB01:{x:355}, DST01:{x:670} };
  svg += arrow(mainPos.LTR01.x+BW, mainY+BH/2, mainPos.SUB01.x, mainY+BH/2, '#007E7A');
  svg += arrow(mainPos.SUB01.x+BW, mainY+BH/2, mainPos.DST01.x, mainY+BH/2, '#045552');
  svg += arrow(mainPos.DST01.x+BW, mainY+BH/2, W-40, mainY+BH/2, '#00B0CA');
  svg += `<text x="${mainPos.DST01.x+BW+18}" y="${mainY+BH/2-8}" font-size="9.5" font-weight="700" fill="${CHART_THEME.mutedText}">SUBESTAÇÕES</text>`;
  Object.keys(mainPos).forEach(code=>{ svg += box(code, mainPos[code].x, mainY, BW, BH, false); });

  // seta descendo do DST01 para a grade
  svg += arrow(mainPos.DST01.x+BW/2, mainY+BH, mainPos.DST01.x+BW/2, mainY+BH+38, '#00B0CA');

  // ---- grade de subestações unitárias (SUB02..SUB16) ----
  const gridLabelY = mainY+BH+58;
  svg += `<line x1="20" y1="${gridLabelY-16}" x2="${W-20}" y2="${gridLabelY-16}" stroke="${CHART_THEME.gridLine}" stroke-dasharray="2,3"/>`;
  svg += `<text x="40" y="${gridLabelY}" font-size="11" font-weight="700" fill="${CHART_THEME.mutedText}" letter-spacing="0.5">SUBESTAÇÕES UNITÁRIAS (13,8 kV)</text>`;
  const subs = ['SUB02','SUB03','SUB04','SUB05','SUB06','SUB07','SUB08','SUB09','SUB10','SUB11','SUB12','SUB13','SUB14','SUB15','SUB16'];
  const cols = 5;
  const gridX0 = 40, gridY0 = gridLabelY+14;
  const stepX = (W-80-GW)/(cols-1);
  const stepY = GH+18;
  let gridBottom = gridY0;
  subs.forEach((code,i)=>{
    const cx = gridX0 + (i%cols)*stepX;
    const cy = gridY0 + Math.floor(i/cols)*stepY;
    gridBottom = Math.max(gridBottom, cy+GH);
    svg += box(code, cx, cy, GW, GH, false);
  });

  // ---- distribuição / alimentadores auxiliares (DST02..DST09) ----
  const auxLabelY = gridBottom + 34;
  svg += `<line x1="20" y1="${auxLabelY-16}" x2="${W-20}" y2="${auxLabelY-16}" stroke="${CHART_THEME.gridLine}" stroke-dasharray="2,3"/>`;
  svg += `<text x="40" y="${auxLabelY}" font-size="11" font-weight="700" fill="${CHART_THEME.mutedText}" letter-spacing="0.5">DISTRIBUIÇÃO / ALIMENTADORES AUXILIARES</text>`;
  const auxCodes = ['DST02','DST03','DST04','DST05','DST06','DST07','DST08','DST09'];
  const auxY = auxLabelY+14;
  const auxStep = (W-80-AW)/(auxCodes.length-1);
  auxCodes.forEach((code,i)=>{
    svg += box(code, 40 + i*auxStep, auxY, AW, AH, true);
  });

  // ---- barra resumo geral ----
  let totalAll=0, totalConcl=0, totalAnd=0;
  Object.keys(SISTEMA_META).forEach(k=>{ const c=counts[k]||{total:0,concl:0,andamento:0}; totalAll+=c.total; totalConcl+=c.concl; totalAnd+=(c.andamento||0); });
  const summaryPct = totalAll ? (totalConcl/totalAll*100) : 0;
  const summaryPctAnd = totalAll ? (totalAnd/totalAll*100) : 0;
  const sumX = 40, sumW = W-80;
  const dividerY = auxY + AH + 34;
  const labelY2 = dividerY + 18;
  const barY2 = labelY2 + 14;
  svg += `<line x1="${sumX}" y1="${dividerY}" x2="${sumX+sumW}" y2="${dividerY}" stroke="${CHART_THEME.gridLine}"/>`;
  svg += `<text x="${sumX}" y="${labelY2}" font-size="10" fill="${CHART_THEME.mutedText}">Concluído no fluxo${fluxoViewMode==='pilar' && fluxoPilar ? ' · '+fluxoPilar : ' (geral)'}</text>`;
  svg += `<text x="${sumX+sumW}" y="${labelY2}" font-size="10" fill="${CHART_THEME.mutedText}" text-anchor="end">${totalConcl} concluídos${totalAnd? ' + '+totalAnd+' em andamento':''} de ${totalAll} itens · ${summaryPct.toFixed(0)}%</text>`;
  svg += `<rect x="${sumX}" y="${barY2}" width="${sumW}" height="3" rx="1.5" fill="${CHART_THEME.gridLine}"/>`;
  if(summaryPctAnd>0) svg += `<rect x="${sumX+sumW*summaryPct/100}" y="${barY2}" width="${Math.min(sumW*summaryPctAnd/100, sumW-sumW*summaryPct/100)}" height="3" rx="1.5" fill="#045552" opacity="0.35"/>`;
  svg += `<rect x="${sumX}" y="${barY2}" width="${sumW*summaryPct/100}" height="3" rx="1.5" fill="#045552"/>`;
  svg += `<circle cx="${sumX+sumW*summaryPct/100}" cy="${barY2+1.5}" r="3.5" fill="#045552"/>`;

  const totalH = barY2 + 40;
  const fullSvg = `<g transform="translate(0,28)">${svg}</g>`;
  ['a_fluxoSvg','a_fluxoSvg_fs'].forEach(id=>{
    const el = document.getElementById(id);
    if(!el) return;
    el.setAttribute('viewBox', `0 0 ${W} ${totalH+28}`);
    if(id==='a_fluxoSvg') el.style.height = (totalH+28) + 'px';
    el.innerHTML = fullSvg;
  });
}


function renderHeatmap(){
  const start = startDateOverall();
  const weeksTotal = globalWeeksTotal(start);
  let maxDate = new Date(start.getTime()+weeksTotal*7*24*60*60*1000);
  let numPeriods;
  if(mapaGranularidade==='semana') numPeriods = weeksTotal+1;
  else if(mapaGranularidade==='mes') numPeriods = periodIndexFor(maxDate,'mes',start)+1;
  else numPeriods = periodIndexFor(maxDate,'ano',start)+1;
  numPeriods = Math.max(1, numPeriods);

  let html = '<thead><tr><th class="row-head">Equipe</th>';
  for(let p=0;p<numPeriods;p++) html += `<th>${periodLabel(mapaGranularidade,p,start)}</th>`;
  html += '<th>Total</th></tr></thead><tbody>';

  CHART_PILARES.forEach(pilar=>{
    const rowCounts = new Array(numPeriods).fill(0);
    let total=0;
    items.forEach(i=>{
      if(i.pilar!==pilar) return;
      total++;
      const d = parseDate(i.plan_end);
      if(!d) return;
      let idx = periodIndexFor(d, mapaGranularidade, start);
      idx = Math.max(0, Math.min(numPeriods-1, idx));
      rowCounts[idx]++;
    });
    const rowMax = Math.max(1, ...rowCounts);
    html += `<tr><td class="row-head"><span class="dot" style="background:${PILAR_COLOR_HEX[pilar]};margin-right:6px;"></span>${pilar}</td>`;
    rowCounts.forEach(val=>{
      if(val===0){
        html += `<td class="zero">0</td>`;
      }else{
        const hex = PILAR_COLOR_HEX[pilar];
        const r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
        const alpha = 0.18 + 0.62*(val/rowMax);
        html += `<td style="background:rgba(${r},${g},${b},${alpha.toFixed(2)});">${val}</td>`;
      }
    });
    html += `<td style="font-weight:700;">${total}</td></tr>`;
  });
  html += '</tbody>';
  document.getElementById('a_heatmapTable').innerHTML = html;
}
function renderFluxoPilarSelect(){
  const el = document.getElementById('a_fluxoPilarSelect');
  if(!fluxoPilar) fluxoPilar = CHART_PILARES[0];
  el.innerHTML = CHART_PILARES.map(p=>{
    const active = p===fluxoPilar;
    return `<button class="team-chip${active?' active-chip':''}" data-pilar="${p}"
      style="${active?`background:${PILAR_COLOR_HEX[p]};color:#fff;`:`color:${PILAR_COLOR_HEX[p]};`}">
      <span class="dot" style="background:${PILAR_COLOR_HEX[p]};"></span>${p}
    </button>`;
  }).join('');
  el.querySelectorAll('button[data-pilar]').forEach(btn=>{
    btn.addEventListener('click',()=>{
      fluxoPilar = btn.dataset.pilar;
      renderFluxoPilarSelect();
      renderFluxoBlocos();
    });
  });
}

document.getElementById('a_fluxoToggle').addEventListener('click', function(e){
  const btn = e.target.closest('button');
  if(!btn) return;
  fluxoViewMode = btn.dataset.mode;
  this.querySelectorAll('button').forEach(b=>b.classList.toggle('active', b===btn));
  const selEl = document.getElementById('a_fluxoPilarSelect');
  if(fluxoViewMode==='pilar'){
    selEl.style.display = '';
    renderFluxoPilarSelect();
  } else {
    selEl.style.display = 'none';
  }
  renderFluxoBlocos();
});

document.getElementById('a_mapaToggle').addEventListener('click', function(e){
  const btn = e.target.closest('button');
  if(!btn) return;
  mapaGranularidade = btn.dataset.gran;
  this.querySelectorAll('button').forEach(b=>b.classList.toggle('active', b===btn));
  renderHeatmap();
});

document.getElementById('a_desvioToggle').addEventListener('click', function(e){
  const btn = e.target.closest('button');
  if(!btn) return;
  desvioViewMode = btn.dataset.mode;
  this.querySelectorAll('button').forEach(b=>b.classList.toggle('active', b===btn));
  renderDesvioBarras();
});

document.getElementById('a_desvioSubToggle').addEventListener('click', function(e){
  const btn = e.target.closest('button');
  if(!btn) return;
  desvioSubView = btn.dataset.sub;
  this.querySelectorAll('button').forEach(b=>b.classList.toggle('active', b===btn));
  const subEl = document.getElementById('a_desvioSub');
  if(subEl){
    subEl.innerHTML = desvioSubView==='atrasado'
      ? 'Dos itens classificados como <strong>atrasados</strong>, quantos têm a causa atribuída à <strong>Tenax</strong> (status ainda não concluído, ou validação "Ag. envio") e quantos à <strong>Vale</strong> (validação "Em análise" com retorno além do previsto)'
      : 'Atraso/adiantamento <strong>médio</strong> (dias) dos itens já concluídos, com a divisão entre quantos foram entregues adiantados, no prazo ou com atraso — Geral combina as equipes selecionadas acima; Por pilar mostra uma barra para cada uma';
  }
  renderDesvioBarras();
});

// ===== Toggle Geral/Por pilar curva individual =====
document.getElementById('a_geralToggle').addEventListener('click', function(e){
  const btn = e.target.closest('button');
  if(!btn) return;
  individualViewMode = btn.dataset.mode;
  this.querySelectorAll('button').forEach(b=>b.classList.toggle('active', b===btn));
  renderCurvaIndividual();
});

// ---------- tabela ----------
function statusClass(s){
  if(s==='Concluído') return 'status-concluido';
  if(s==='Em execução' || s==='Em andamento') return 'status-execucao';
  return 'status-naoiniciado';
}
function populateFilters(){
  document.getElementById('a_pilarFilter').innerHTML = '<option value="">Todos os pilares</option>' +
    PILAR_ORDER.map(p=>`<option value="${p}">${p}</option>`).join('');
  const sistemas = Array.from(new Set(items.map(i=>i.sistema))).filter(Boolean).sort();
  document.getElementById('a_sistemaFilter').innerHTML = '<option value="">Todos os sistemas</option>' +
    sistemas.map(s=>`<option value="${s}">${s}</option>`).join('');
}
function renderTable(){
  const search = document.getElementById('a_searchInput').value.toLowerCase();
  const pilar = document.getElementById('a_pilarFilter').value;
  const sistema = document.getElementById('a_sistemaFilter').value;
  const status = document.getElementById('a_statusFilter').value;
  const filtered = items.filter(i=>{
    if(pilar && i.pilar!==pilar) return false;
    if(sistema && i.sistema!==sistema) return false;
    if(status && i.status!==status) return false;
    if(search){
      const hay = [i.ativo, i.floc, i.sistema, i.denom, i.pilar, i.status].filter(Boolean).join(' ').toLowerCase();
      if(!hay.includes(search)) return false;
    }
    return true;
  });
  filtered.sort((a,b)=>{
    const da=a.plan_end||'9999', db=b.plan_end||'9999';
    return da.localeCompare(db);
  });
  document.getElementById('a_rowCount').textContent = `${filtered.length} de ${items.length} linhas`;
  if(items.length===0){
    const areaBtnT = currentArea==='energia' ? '⚡ Energia' : '🪨 Britagem III';
    document.getElementById('a_tableBody').innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:24px;">Nenhuma planilha de ' + AREA_LABEL[currentArea] + ' carregada ainda — clique no botão 🔄 Atualizar dados e envie a planilha ' + areaBtnT + '.</td></tr>';
    return;
  }
  document.getElementById('a_tableBody').innerHTML = filtered.map(i=>`
    <tr>
      <td><span class="pilar-chip" style="background:${PILAR_COLOR_HEX[i.pilar]}22;color:${PILAR_COLOR_HEX[i.pilar]};">${i.pilar}</span></td>
      <td>${i.sistema}</td>
      <td>
        <div class="floc-main">${i.ativo}</div>
        <div class="floc-sub">${i.floc}${i.denom?' · '+i.denom:''}</div>
      </td>
      <td>${fmtDate(i.plan_start)}</td>
      <td>${fmtDate(i.plan_end)}</td>
      <td><span class="status-tag ${statusClass(i.status)}">${i.status}</span></td>
      <td class="conclusao-cell">${fmtDate(i.real_end)}</td>
    </tr>
  `).join('');
}

function showChartError(svgId, subId, err){
  console.error(err);
  const svg = document.getElementById(svgId);
  if(svg) svg.innerHTML = `<text x="20" y="40" font-size="12" fill="${CHART_THEME.errorText}">Erro ao desenhar este gráfico: ${(err && err.message) || err}</text>`;
  const sub = document.getElementById(subId);
  if(sub) sub.textContent = 'Falha ao calcular esta curva — veja a mensagem em vermelho acima e o console do navegador (F12) para detalhes.';
}

function safe(label, fn){
  try{ fn(); }catch(err){ console.error('Falha em '+label+':', err); }
}

// Estado vazio: mostrado até o upload da planilha do processo
function renderEmptyDashboard(){
  const areaBtn = currentArea==='energia' ? '⚡ Energia' : '🪨 Britagem III';
  const msg = `Sem dados de ${AREA_LABEL[currentArea]} — clique no botão 🔄 Atualizar dados e carregue a planilha ${areaBtn}`;

  document.getElementById('a_kpiRow').innerHTML = [
    {label:'Processos ativos', value:'—', sub:'aguardando planilha'},
    {label:'Horizonte', value:'—', sub:'aguardando planilha'},
    {label:'Em andamento', value:'—', sub:'aguardando planilha'},
    {label:'Total geral', value:'0', sub:'nenhum item carregado'},
    {label:'Total sem Inventário', value:'0', sub:'nenhum item carregado'},
    {label:'% concluído', value:'—', sub:'0 de 0'},
  ].map(c=>`
    <div class="kpi-card">
      <div class="kpi-label">${c.label}</div>
      <div class="kpi-value">${c.value}</div>
      <div class="kpi-sub">${c.sub}</div>
    </div>`).join('');

  function svgMsg(id, w, h, fixHeight){
    const el = document.getElementById(id); if(!el) return;
    el.setAttribute('viewBox', `0 0 ${w} ${h}`);
    if(fixHeight) el.style.height = h + 'px';
    el.innerHTML = `<text x="${w/2}" y="${h/2}" text-anchor="middle" font-size="14" fill="${CHART_THEME.mutedText}">${msg}</text>`;
  }
  svgMsg('a_fluxoSvg', 1180, 300, true);
  svgMsg('a_fluxoSvg_fs', 1180, 300, false);
  svgMsg('a_curvaIndividualSvg', 900, 340, false);
  svgMsg('a_curvaConsSvg', 1180, 500, false);

  const clearIds = ['a_teamSelectIndividual','a_teamSelectConsolidada','a_legendIndividual','a_legendConsolidada','a_pilarBars','a_heatmapTable'];
  clearIds.forEach(id=>{ const el=document.getElementById(id); if(el) el.innerHTML=''; });
  const sub = document.getElementById('a_curvaConsSub'); if(sub) sub.textContent = msg;
  const desvio = document.getElementById('a_desvioBarras');
  if(desvio) desvio.innerHTML = `<div style="text-align:center;color:${CHART_THEME.mutedText};padding:24px;font-size:13px;">${msg}</div>`;
  const fluxoSel = document.getElementById('a_fluxoPilarSelect'); if(fluxoSel) fluxoSel.style.display='none';

  safe('populateFilters', populateFilters);
  safe('renderTable', renderTable);
}

function renderAll(){
  if(items.length===0){ renderEmptyDashboard(); return; }
  safe('renderKPIs', renderKPIs);
  safe('renderFluxoBlocos', renderFluxoBlocos);
  safe('renderTeamSelectIndividual', ()=>renderTeamSelect('a_teamSelectIndividual', selectedIndividual, renderCurvaIndividual));
  safe('renderTeamSelectConsolidada', ()=>renderTeamSelectConsolidada());
  try{ renderCurvaIndividual(); }catch(err){ showChartError('a_curvaIndividualSvg', null, err); }
  try{ renderCurvaConsolidada(); }catch(err){ showChartError('a_curvaConsSvg', 'a_curvaConsSub', err); }
  safe('renderPilarBars', renderPilarBars);
  safe('renderHeatmap', renderHeatmap);
  safe('populateFilters', populateFilters);
  safe('renderTable', renderTable);
}

['a_searchInput','a_pilarFilter','a_sistemaFilter','a_statusFilter'].forEach(id=>{
  document.getElementById(id).addEventListener('input', renderTable);
  document.getElementById(id).addEventListener('change', renderTable);
});

// ===== Geração do relatório PDF =====
async function generatePdfReport(btnEl){
  if(typeof window.jspdf === 'undefined'){
    alert('Biblioteca de PDF não carregada.');
    return;
  }
  if(items.length===0){
    alert('Carregue a planilha de ' + AREA_LABEL[currentArea] + ' antes de gerar o relatório.');
    return;
  }
  if(btnEl){ btnEl.disabled = true; btnEl.dataset.origText = btnEl.textContent; btnEl.textContent = '⏳ Gerando relatório...'; }

  // ----- salvar estado atual para restaurar depois -----
  const savedState = {
    fluxoViewMode, fluxoPilar,
    selectedConsolidada: new Set(selectedConsolidada),
    mapaGranularidade
  };

  try{
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation:'landscape', unit:'pt', format:'a4' });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 36;
    let firstPage = true;

    function addImagePage(title, sub, imgData){
      if(!firstPage) doc.addPage();
      firstPage = false;
      doc.setFillColor(244,245,247);
      doc.rect(0,0,pageW,pageH,'F');
      doc.setFont('helvetica','bold');
      doc.setFontSize(15);
      doc.setTextColor(4,85,82);
      doc.text(title, margin, margin+6);
      if(sub){
        doc.setFont('helvetica','normal');
        doc.setFontSize(10);
        doc.setTextColor(100,112,133);
        doc.text(sub, margin, margin+24);
      }
      const availW = pageW - margin*2;
      const availH = pageH - margin*2 - 46;
      const ratio = Math.min(availW/imgData.width, availH/imgData.height);
      const w = imgData.width*ratio, h = imgData.height*ratio;
      const x = margin + (availW-w)/2;
      const y = margin + 46;
      doc.addImage(imgData.dataUrl, 'PNG', x, y, w, h);
    }

    // ----- capa -----
    doc.setFillColor(4,85,82);
    doc.rect(0,0,pageW,pageH,'F');
    doc.setTextColor(255,255,255);
    doc.setFont('helvetica','bold');
    doc.setFontSize(26);
    doc.text('Relatório de Acompanhamento', pageW/2, pageH/2-30, {align:'center'});
    doc.setFont('helvetica','normal');
    doc.setFontSize(13);
    doc.text('Cronogramas de Acompanhamento — '+AREA_LABEL[currentArea], pageW/2, pageH/2+2, {align:'center'});
    const dateLabel = new Date().toLocaleDateString('pt-BR', {day:'2-digit', month:'long', year:'numeric'});
    doc.setFontSize(11);
    doc.text('Gerado em '+dateLabel, pageW/2, pageH/2+26, {align:'center'});
    firstPage = false;

    // ----- 1) Fluxograma de blocos (resumo geral) -----
    fluxoViewMode = 'geral'; fluxoPilar = null;
    renderAll();
    await waitFrame();
    const fluxoImg = await svgToImageData('a_fluxoSvg');
    addImagePage(AREA_FLUXO_TITLE[currentArea], 'Resumo geral (todos os pilares combinados)', fluxoImg);

    // ----- 2) Curva S consolidada — geral (Todos os pilares) -----
    selectedConsolidada.clear();
    CHART_PILARES.forEach(p=>selectedConsolidada.add(p));
    renderAll();
    await waitFrame();
    const curvaGeralImg = await svgToImageData('a_curvaConsSvg');
    addImagePage('Curva S consolidada do projeto', 'Visão geral — todos os pilares combinados', curvaGeralImg);

    // ----- 3) Curva S consolidada — por pilar -----
    for(const p of CHART_PILARES){
      selectedConsolidada.clear();
      selectedConsolidada.add(p);
      renderAll();
      await waitFrame();
      const curvaPilarImg = await svgToImageData('a_curvaConsSvg');
      addImagePage('Curva S consolidada do projeto', 'Pilar: '+p, curvaPilarImg);
    }

    // ----- 4) Mapa de entregas por equipe (por semana) -----
    mapaGranularidade = 'semana';
    renderAll();
    await waitFrame();
    const mapaImg = await elementToImageData('a_heatmapWrap');
    addImagePage('Mapa de entregas por equipe', 'Quantidade de itens com entrega planejada — granularidade semanal', mapaImg);

    const fileDate = new Date().toISOString().slice(0,10);
    doc.save(`relatorio-acompanhamento-${fileDate}.pdf`);

  } catch(err){
    alert('Não foi possível gerar o relatório: ' + err.message);
  } finally {
    // ----- restaurar estado original -----
    fluxoViewMode = savedState.fluxoViewMode;
    fluxoPilar = savedState.fluxoPilar;
    selectedConsolidada.clear();
    savedState.selectedConsolidada.forEach(p=>selectedConsolidada.add(p));
    mapaGranularidade = savedState.mapaGranularidade;
    renderAll();

    const selEl = document.getElementById('a_fluxoPilarSelect');
    if(selEl) selEl.style.display = (fluxoViewMode==='pilar') ? '' : 'none';
    document.querySelectorAll('#a_fluxoToggle button').forEach(b=>b.classList.toggle('active', b.dataset.mode===fluxoViewMode));
    document.querySelectorAll('#a_mapaToggle button').forEach(b=>b.classList.toggle('active', b.dataset.gran===mapaGranularidade));

    if(btnEl){ btnEl.disabled=false; btnEl.textContent = btnEl.dataset.origText || '📑 Exportar relatório (PDF)'; }
  }
}

// ---------- troca de área (Britagem / Energia) ----------
function setArea(area){
  if(!areaItems[area]) return;
  currentArea = area;
  items = areaItems[area];
  SISTEMA_META = (area==='energia') ? SISTEMA_META_ENERGIA : SISTEMA_META_BRITAGEM;
  // reseta o fluxograma para a visão geral, para o redesenho ficar evidente após uma atualização
  fluxoViewMode = 'geral';
  fluxoPilar = null;
  const fluxoSel = document.getElementById('a_fluxoPilarSelect');
  if(fluxoSel) fluxoSel.style.display = 'none';
  document.querySelectorAll('#a_fluxoToggle button').forEach(b=>b.classList.toggle('active', b.dataset.mode==='geral'));
  selectedIndividual = new Set(CHART_PILARES);
  selectedConsolidada = new Set(CHART_PILARES);

  // títulos e legendas dependentes da área
  const t = AREA_FLUXO_TITLE[area];
  const h = document.querySelector('#panelFluxo .chart-panel-header h2'); if(h) h.textContent = t;
  const hfs = document.querySelector('#fs_fluxo .chart-fullscreen-header h2'); if(hfs) hfs.textContent = t;
  const sub = document.querySelector('#panelFluxo .chart-panel-header .sub'); if(sub) sub.textContent = AREA_FLUXO_SUB[area];
  document.querySelectorAll('button[data-filename^="fluxograma-blocos"]').forEach(b=>{
    b.dataset.filename = 'fluxograma-blocos-' + (area==='energia' ? 'energia' : 'britagem');
  });

  renderAll();
}

return { renderAll, rebuildFromWorkbook, rebuildAreaFromWorkbook, generatePdfReport, setArea };
})();
// ===== Download de gráfico como PNG (alta qualidade) =====
function downloadSvgAsPng(svgId, filename, btnEl){
  const svg = document.getElementById(svgId);
  if(!svg) return;
  if(btnEl){ btnEl.disabled = true; btnEl.textContent='⏳'; }

  const SCALE = 4; // fator de escala para alta resolução (equivalente a ~4x retina)
  const vb = (svg.getAttribute('viewBox')||'').split(/\s+/).map(Number);
  const baseW = vb.length===4 ? vb[2] : (svg.clientWidth||1180);
  const baseH = vb.length===4 ? vb[3] : (svg.clientHeight||480);

  const bgColor = getComputedStyle(document.body).getPropertyValue('--bg2').trim() || '#FFFFFF';

  // Clonar o SVG e garantir width/height explícitos (necessário para rasterizar corretamente)
  const clone = svg.cloneNode(true);
  clone.removeAttribute('style');
  clone.setAttribute('width', baseW);
  clone.setAttribute('height', baseH);
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

  const svgString = new XMLSerializer().serializeToString(clone);
  const svgBlob = new Blob([svgString], {type:'image/svg+xml;charset=utf-8'});
  const url = URL.createObjectURL(svgBlob);

  const img = new Image();
  img.onload = function(){
    const canvas = document.createElement('canvas');
    canvas.width = baseW * SCALE;
    canvas.height = baseH * SCALE;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = bgColor;
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.scale(SCALE, SCALE);
    ctx.drawImage(img, 0, 0, baseW, baseH);
    URL.revokeObjectURL(url);

    canvas.toBlob(function(blob){
      const a = document.createElement('a');
      const dateTag = new Date().toISOString().slice(0,10);
      a.href = URL.createObjectURL(blob);
      a.download = `${filename}-${dateTag}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(a.href);
      if(btnEl){ btnEl.disabled=false; btnEl.textContent='⬇'; }
    }, 'image/png', 1.0);
  };
  img.onerror = function(){
    URL.revokeObjectURL(url);
    if(btnEl){ btnEl.disabled=false; btnEl.textContent='⬇'; }
    alert('Não foi possível gerar a imagem deste gráfico.');
  };
  img.src = url;
}

// ===== Download de elemento HTML (tabela/heatmap) como PNG (alta qualidade) =====
function inlineComputedStyles(srcEl, dstEl){
  const props = ['color','background-color','background-image','border-top','border-right','border-bottom','border-left',
    'border-radius','padding','margin','font-size','font-weight','font-family','text-align','vertical-align',
    'width','height','min-width','min-height','line-height','opacity','box-shadow','display','white-space',
    'border-collapse','border-spacing'];
  const srcAll = [srcEl, ...srcEl.querySelectorAll('*')];
  const dstAll = [dstEl, ...dstEl.querySelectorAll('*')];
  srcAll.forEach((s,i)=>{
    const d = dstAll[i];
    if(!d || !d.setAttribute) return;
    const cs = getComputedStyle(s);
    let styleStr = '';
    props.forEach(p=>{
      const v = cs.getPropertyValue(p);
      if(v) styleStr += `${p}:${v};`;
    });
    d.setAttribute('style', styleStr);
  });
}

function downloadElementAsPng(elementId, filename, btnEl){
  const el = document.getElementById(elementId);
  if(!el) return;
  if(btnEl){ btnEl.disabled = true; btnEl.textContent='⏳'; }

  const SCALE = 3;
  const width = Math.ceil(el.scrollWidth) || el.getBoundingClientRect().width;
  const height = Math.ceil(el.scrollHeight) || el.getBoundingClientRect().height;
  const bgColor = getComputedStyle(document.body).getPropertyValue('--bg2').trim() || '#FFFFFF';

  const clone = el.cloneNode(true);
  inlineComputedStyles(el, clone);
  clone.removeAttribute('id');

  const wrapperHtml = `<div xmlns="http://www.w3.org/1999/xhtml" style="background:${bgColor};padding:16px;display:inline-block;">${clone.outerHTML}</div>`;
  const svgString = `<svg xmlns="http://www.w3.org/2000/svg" width="${width+32}" height="${height+32}">
    <foreignObject width="100%" height="100%">${wrapperHtml}</foreignObject>
  </svg>`;

  const svgBlob = new Blob([svgString], {type:'image/svg+xml;charset=utf-8'});
  const url = URL.createObjectURL(svgBlob);

  const img = new Image();
  img.onload = function(){
    const canvas = document.createElement('canvas');
    canvas.width = (width+32) * SCALE;
    canvas.height = (height+32) * SCALE;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = bgColor;
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.scale(SCALE, SCALE);
    ctx.drawImage(img, 0, 0, width+32, height+32);
    URL.revokeObjectURL(url);

    canvas.toBlob(function(blob){
      const a = document.createElement('a');
      const dateTag = new Date().toISOString().slice(0,10);
      a.href = URL.createObjectURL(blob);
      a.download = `${filename}-${dateTag}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(a.href);
      if(btnEl){ btnEl.disabled=false; btnEl.textContent='⬇'; }
    }, 'image/png', 1.0);
  };
  img.onerror = function(){
    URL.revokeObjectURL(url);
    if(btnEl){ btnEl.disabled=false; btnEl.textContent='⬇'; }
    alert('Não foi possível gerar a imagem deste elemento.');
  };
  img.src = url;
}

function initDownloadButtons(){
  document.querySelectorAll('.download-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      if(btn.dataset.svg){
        downloadSvgAsPng(btn.dataset.svg, btn.dataset.filename, btn);
      } else if(btn.dataset.el){
        downloadElementAsPng(btn.dataset.el, btn.dataset.filename, btn);
      }
    });
  });
}

// ===== Captura de imagem (Promise) reutilizável pelo gerador de PDF =====
function svgToImageData(svgId){
  return new Promise((resolve, reject)=>{
    const svg = document.getElementById(svgId);
    if(!svg){ reject(new Error('SVG não encontrado: '+svgId)); return; }
    const SCALE = 3;
    const vb = (svg.getAttribute('viewBox')||'').split(/\s+/).map(Number);
    const baseW = vb.length===4 ? vb[2] : (svg.clientWidth||1180);
    const baseH = vb.length===4 ? vb[3] : (svg.clientHeight||480);
    const bgColor = getComputedStyle(document.body).getPropertyValue('--bg2').trim() || '#FFFFFF';

    const clone = svg.cloneNode(true);
    clone.removeAttribute('style');
    clone.setAttribute('width', baseW);
    clone.setAttribute('height', baseH);
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

    const svgString = new XMLSerializer().serializeToString(clone);
    const svgBlob = new Blob([svgString], {type:'image/svg+xml;charset=utf-8'});
    const url = URL.createObjectURL(svgBlob);

    const img = new Image();
    img.onload = function(){
      const canvas = document.createElement('canvas');
      canvas.width = baseW * SCALE;
      canvas.height = baseH * SCALE;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = bgColor;
      ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.scale(SCALE, SCALE);
      ctx.drawImage(img, 0, 0, baseW, baseH);
      URL.revokeObjectURL(url);
      resolve({dataUrl: canvas.toDataURL('image/png', 1.0), width: baseW, height: baseH});
    };
    img.onerror = function(){ URL.revokeObjectURL(url); reject(new Error('Falha ao rasterizar SVG: '+svgId)); };
    img.src = url;
  });
}

function elementToImageData(elementId){
  return new Promise((resolve, reject)=>{
    const el = document.getElementById(elementId);
    if(!el){ reject(new Error('Elemento não encontrado: '+elementId)); return; }
    const SCALE = 3;
    const width = Math.ceil(el.scrollWidth) || el.getBoundingClientRect().width;
    const height = Math.ceil(el.scrollHeight) || el.getBoundingClientRect().height;
    const bgColor = getComputedStyle(document.body).getPropertyValue('--bg2').trim() || '#FFFFFF';

    const clone = el.cloneNode(true);
    inlineComputedStyles(el, clone);
    clone.removeAttribute('id');

    const wrapperHtml = `<div xmlns="http://www.w3.org/1999/xhtml" style="background:${bgColor};padding:16px;display:inline-block;">${clone.outerHTML}</div>`;
    const svgString = `<svg xmlns="http://www.w3.org/2000/svg" width="${width+32}" height="${height+32}">
      <foreignObject width="100%" height="100%">${wrapperHtml}</foreignObject>
    </svg>`;

    const svgBlob = new Blob([svgString], {type:'image/svg+xml;charset=utf-8'});
    const url = URL.createObjectURL(svgBlob);

    const img = new Image();
    img.onload = function(){
      const canvas = document.createElement('canvas');
      canvas.width = (width+32) * SCALE;
      canvas.height = (height+32) * SCALE;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = bgColor;
      ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.scale(SCALE, SCALE);
      ctx.drawImage(img, 0, 0, width+32, height+32);
      URL.revokeObjectURL(url);
      resolve({dataUrl: canvas.toDataURL('image/png', 1.0), width: width+32, height: height+32});
    };
    img.onerror = function(){ URL.revokeObjectURL(url); reject(new Error('Falha ao rasterizar elemento: '+elementId)); };
    img.src = url;
  });
}

function waitFrame(){ return new Promise(r=>setTimeout(r, 60)); }



// ===== Zoom & Pan engine (global — fora do IIFE) =====
function initZoom(wrapperId, svgId){
  const wrap = document.getElementById(wrapperId);
  const svg = document.getElementById(svgId);
  if(!wrap||!svg) return;
  // Remover listeners antigos clonando o elemento
  const newWrap = wrap.cloneNode(false);
  while(wrap.firstChild) newWrap.appendChild(wrap.firstChild);
  wrap.parentNode.replaceChild(newWrap, wrap);
  const w2 = newWrap, s2 = document.getElementById(svgId);
  let scale=1, tx=0, ty=0, dragging=false, startX=0, startY=0, startTx=0, startTy=0;
  function applyTransform(){ s2.style.transform=`translate(${tx}px,${ty}px) scale(${scale})`; }
  w2.addEventListener('wheel', e=>{
    e.preventDefault();
    const rect=w2.getBoundingClientRect();
    const mx=e.clientX-rect.left, my=e.clientY-rect.top;
    const delta=-e.deltaY*0.001;
    const newScale=Math.max(0.5,Math.min(8,scale*(1+delta)));
    tx=mx-(mx-tx)*(newScale/scale); ty=my-(my-ty)*(newScale/scale);
    scale=newScale; applyTransform();
  },{passive:false});
  w2.addEventListener('mousedown',e=>{ dragging=true; startX=e.clientX; startY=e.clientY; startTx=tx; startTy=ty; s2.style.cursor='grabbing'; e.preventDefault(); });
  document.addEventListener('mousemove',e=>{ if(!dragging) return; tx=startTx+(e.clientX-startX); ty=startTy+(e.clientY-startY); applyTransform(); });
  document.addEventListener('mouseup',()=>{ if(dragging){ dragging=false; s2.style.cursor='grab'; } });
  w2.addEventListener('dblclick',()=>{ scale=1; tx=0; ty=0; applyTransform(); });
}

// ===== Fullscreen expand (global) =====
function initExpand(){
  const FS_MAP = {
    panelFluxo: {fsId:'fs_fluxo', svg:'a_fluxoSvg', svgFs:'a_fluxoSvg_fs', zoomFs:'zoomFluxo_fs'},
    panelIndividual: {fsId:'fs_individual', svg:'a_curvaIndividualSvg', svgFs:'a_curvaIndividualSvg_fs', zoomFs:'zoomIndividual_fs', leg:'a_legendIndividual', legFs:'a_legendIndividual_fs'},
    panelConsolidada: {fsId:'fs_consolidada', svg:'a_curvaConsSvg', svgFs:'a_curvaConsSvg_fs', zoomFs:'zoomConsolidada_fs', leg:'a_legendConsolidada', legFs:'a_legendConsolidada_fs'},
  };
  document.querySelectorAll('.expand-btn').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const target=btn.dataset.target;
      const cfg = FS_MAP[target];
      if(!cfg) return;
      const fs=document.getElementById(cfg.fsId);
      if(!fs) return;
      fs.classList.add('open');
      const src=document.getElementById(cfg.svg);
      const dst=document.getElementById(cfg.svgFs);
      if(src&&dst) dst.innerHTML=src.innerHTML;
      if(cfg.leg){
        const legSrc=document.getElementById(cfg.leg);
        const legDst=document.getElementById(cfg.legFs);
        if(legSrc&&legDst) legDst.innerHTML=legSrc.innerHTML;
      }
      setTimeout(()=>initZoom(cfg.zoomFs, cfg.svgFs),50);
    });
  });
  const closeF=document.getElementById('fs_fluxo_close');
  const closeI=document.getElementById('fs_individual_close');
  const closeC=document.getElementById('fs_consolidada_close');
  if(closeF) closeF.addEventListener('click',()=>document.getElementById('fs_fluxo').classList.remove('open'));
  if(closeI) closeI.addEventListener('click',()=>document.getElementById('fs_individual').classList.remove('open'));
  if(closeC) closeC.addEventListener('click',()=>document.getElementById('fs_consolidada').classList.remove('open'));
  document.addEventListener('keydown',e=>{ if(e.key==='Escape') document.querySelectorAll('.chart-fullscreen').forEach(f=>f.classList.remove('open')); });
}


const MobDash = (function(){

// ===================== CONFIG =====================
const STATUS_ORDER = ['Concluído','Em andamento','Não iniciado','Bloqueado'];
const STATUS_COLOR = {
  'Concluído':'#69BE28',
  'Em andamento':'#EDB111',
  'Não iniciado':'#00B0CA',
  'Bloqueado':'#747678'
};
const STATUS_CLASS = {
  'Concluído':'st-concluido',
  'Em andamento':'st-andamento',
  'Bloqueado':'st-bloqueado',
  'Não iniciado':'st-naoiniciado'
};
// ======================================================================================

const DEFAULT_DATA = [];

let items = DEFAULT_DATA.slice();

function toISO(d){
  if(d===null || d===undefined || d==='') return null;
  const isDateLike = Object.prototype.toString.call(d) === '[object Date]';
  if(isDateLike){
    if(isNaN(d.getTime())) return null;
    const iso = d.toISOString().slice(0,10);
    // Excel grava células "vazias" formatadas como data/hora como 1899-12-30 (data-base) —
    // isso não é uma data real, é o equivalente a "sem valor".
    if(iso === '1899-12-30' || iso === '1899-12-31') return null;
    return iso;
  }
  if(typeof d === 'number'){
    const parsed = XLSX.SSF.parse_date_code(d);
    if(!parsed) return null;
    return `${parsed.y}-${String(parsed.m).padStart(2,'0')}-${String(parsed.d).padStart(2,'0')}`;
  }
  if(typeof d === 'string'){
    const s = d.trim();
    if(/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0,10);
    const m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
    if(m){ let [_,dd,mm,yy]=m; if(yy.length===2) yy='20'+yy; return `${yy}-${mm.padStart(2,'0')}-${dd.padStart(2,'0')}`; }
    return null;
  }
  return null;
}

function rebuildFromWorkbook(workbook){
  const sheetName = workbook.SheetNames.find(n => n.trim().toLowerCase()==='consolidado novo')
    || workbook.SheetNames.find(n => n.trim().toLowerCase().includes('consolidado novo'));
  if(!sheetName) throw new Error('aba "Consolidado Novo" não encontrada nesta planilha');
  const sheet = workbook.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(sheet, {defval:null, header:1});
  // primeira linha = cabeçalho
  const header = rows[0].map(h => (h||'').toString().trim());
  const idx = (name) => header.findIndex(h => h.toLowerCase().startsWith(name.toLowerCase()));
  const iCateg = idx('Categoria'), iGrupo = idx('Grupo'), iNome = idx('Nome'), iFuncao = idx('Função'),
        iItem = idx('Item'), iStatus = idx('Status'), iResp = idx('Responsável'),
        iSol = idx('Data Solicitação'), iPrazo = idx('Prazo'), iConc = idx('Data Conclusão'),
        iLead = idx('Lead Time'), iObs = idx('Observação');

  const recs = [];
  for(let r=1; r<rows.length; r++){
    const row = rows[r];
    if(!row || row.every(v=>v===null||v==='')) continue;
    const categoria = row[iCateg];
    if(!categoria) continue;
    const leadRaw = row[iLead];
    recs.push({
      id: recs.length+1,
      categoria, grupo: row[iGrupo], nome: row[iNome], funcao: row[iFuncao],
      item: row[iItem], status: row[iStatus], responsavel: row[iResp],
      data_solicitacao: toISO(row[iSol]), prazo: toISO(row[iPrazo]), data_conclusao: toISO(row[iConc]),
      lead_time: (typeof leadRaw==='number') ? leadRaw : null,
      observacao: (typeof row[iObs]==='string' && row[iObs].trim() && row[iObs].trim()!=='-') ? row[iObs] : null
    });
  }
  items = recs;
  return items.length;
}

// ---------- utilidades ----------
function parseDate(iso){ return iso ? new Date(iso+'T00:00:00') : null; }
function fmtDate(iso){ const d=parseDate(iso); return d ? d.toLocaleDateString('pt-BR') : '—'; }
function todayISO(){ return new Date().toISOString().slice(0,10); }

function groupCounts(field){
  const groups = {};
  items.forEach(i=>{
    const key = i[field] || '—';
    if(!groups[key]) groups[key] = {total:0};
    STATUS_ORDER.forEach(s=>{ if(groups[key][s]===undefined) groups[key][s]=0; });
    groups[key].total++;
    const st = STATUS_ORDER.includes(i.status) ? i.status : 'Não iniciado';
    groups[key][st]++;
  });
  return groups;
}

// ---------- KPIs ----------
function renderKPIs(){
  const total = items.length;
  const byStatus = {};
  STATUS_ORDER.forEach(s=> byStatus[s] = items.filter(i=>i.status===s).length);
  const pctConcl = total? (byStatus['Concluído']/total*100):0;
  const leadVals = items.filter(i=>i.status==='Concluído' && typeof i.lead_time==='number').map(i=>i.lead_time);
  const leadAvg = leadVals.length? (leadVals.reduce((a,b)=>a+b,0)/leadVals.length) : 0;

  const cards = [
    {label:'Total de itens', value: total, sub: 'na planilha'},
    {label:'Concluído', value: byStatus['Concluído'], sub: pctConcl.toFixed(0)+'% do total — ok', color:'var(--sage)'},
    {label:'Em andamento', value: byStatus['Em andamento'], sub: 'item de atenção', color:'var(--amber)'},
    {label:'Não iniciado', value: byStatus['Não iniciado'], sub: 'alerta — precisa de ação', color:'var(--alert)'},
    {label:'Bloqueado', value: byStatus['Bloqueado'], sub: 'baixa relevância', color:'var(--muted2)'},
    {label:'Lead time médio', value: leadAvg.toFixed(0)+' dias', sub: 'itens concluídos'},
  ];
  document.getElementById('m_kpiRow').innerHTML = cards.map(c=>`
    <div class="kpi-card">
      <div class="kpi-label">${c.label}</div>
      <div class="kpi-value" style="${c.color?('color:'+c.color+';'):''}">${c.value}</div>
      <div class="kpi-sub">${c.sub}</div>
    </div>`).join('');
}

// ---------- curva de avanço (cumulativo de conclusões) ----------
function renderCurva(){
  const MOBILIZACAO_START = new Date('2026-04-01T00:00:00');
  const datesConcl = items.filter(i=>i.data_conclusao).map(i=>parseDate(i.data_conclusao)).sort((a,b)=>a-b);
  if(datesConcl.length===0){
    document.getElementById('m_curvaSvg').innerHTML = `<text x="20" y="40" font-size="12" fill="${CHART_THEME.mutedText2}">Sem datas de conclusão suficientes para montar a curva</text>`;
    return;
  }
  const minDate = MOBILIZACAO_START;
  const maxDate = new Date(Math.max(...datesConcl, minDate.getTime()));
  const totalWeeks = Math.max(1, Math.ceil((maxDate-minDate)/(7*24*60*60*1000))+1);

  const weekly = new Array(totalWeeks+1).fill(0);
  datesConcl.forEach(d=>{
    // datas anteriores a abril/2026 contam todas na semana 0 (início da contagem)
    const w = Math.max(0, Math.min(totalWeeks, Math.floor((d-minDate)/(7*24*60*60*1000))));
    weekly[w]++;
  });
  const total = items.length;
  const cum = new Array(totalWeeks+1).fill(0);
  let acc=0;
  for(let w=0;w<=totalWeeks;w++){ acc+=weekly[w]; cum[w]= acc/total*100; }

  document.getElementById('m_curvaSub').textContent =
    `Conclusões acumuladas (%) de ${minDate.toLocaleDateString('pt-BR')} até ${maxDate.toLocaleDateString('pt-BR')} · ${datesConcl.length} de ${total} itens concluídos com data`;

  const W=820,H=320,padL=46,padR=24,padT=20,padB=40;
  const plotW=W-padL-padR, plotH=H-padT-padB;
  function xPos(w){ return padL + (w/totalWeeks)*plotW; }
  function yPos(v){ return padT + plotH - (v/100)*plotH; }

  let svg='';
  svg += `<line x1="${padL}" y1="${padT}" x2="${padL}" y2="${H-padB}" stroke="${CHART_THEME.axisLine}"/>`;
  svg += `<line x1="${padL}" y1="${H-padB}" x2="${W-padR}" y2="${H-padB}" stroke="${CHART_THEME.axisLine}"/>`;
  [0,20,40,60,80,100].forEach(v=>{
    const y=yPos(v);
    svg += `<line x1="${padL}" y1="${y}" x2="${W-padR}" y2="${y}" stroke="${CHART_THEME.gridLine}"/>`;
    svg += `<text x="${padL-8}" y="${y+4}" font-size="10" fill="${CHART_THEME.axisText}" text-anchor="end">${v}%</text>`;
  });
  const step = Math.max(1, Math.ceil(totalWeeks/16));
  for(let w=0; w<=totalWeeks; w+=step){
    svg += `<text x="${xPos(w)}" y="${H-padB+16}" font-size="9.5" fill="${CHART_THEME.axisText}" text-anchor="middle">S${w}</text>`;
  }
  let d='M'+xPos(0)+','+yPos(0)+' ';
  for(let w=1; w<=totalWeeks; w++) d += 'L'+xPos(w)+','+yPos(cum[w])+' ';
  svg += `<path d="${d}" fill="none" stroke="#007E7A" stroke-width="3"/>`;
  for(let w=0; w<=totalWeeks; w++){
    svg += `<circle cx="${xPos(w)}" cy="${yPos(cum[w]||0)}" r="3" fill="#007E7A"/>`;
  }
  document.getElementById('m_curvaSvg').innerHTML = svg;
}

// ---------- donut de status ----------
function renderDonut(){
  const total = items.length;
  const counts = STATUS_ORDER.map(s=> ({status:s, count: items.filter(i=>i.status===s).length}));
  const cx=110, cy=130, rOuter=95, rInner=58;
  let angle = -Math.PI/2;
  let svg='';
  counts.forEach(c=>{
    if(c.count===0) return;
    const frac = c.count/total;
    const a2 = angle + frac*2*Math.PI;
    const x1o = cx+rOuter*Math.cos(angle), y1o = cy+rOuter*Math.sin(angle);
    const x2o = cx+rOuter*Math.cos(a2), y2o = cy+rOuter*Math.sin(a2);
    const x1i = cx+rInner*Math.cos(a2), y1i = cy+rInner*Math.sin(a2);
    const x2i = cx+rInner*Math.cos(angle), y2i = cy+rInner*Math.sin(angle);
    const large = (a2-angle)>Math.PI ? 1 : 0;
    svg += `<path d="M${x1o},${y1o} A${rOuter},${rOuter} 0 ${large} 1 ${x2o},${y2o} L${x1i},${y1i} A${rInner},${rInner} 0 ${large} 0 ${x2i},${y2i} Z" fill="${STATUS_COLOR[c.status]}"/>`;
    angle = a2;
  });
  svg += `<text x="${cx}" y="${cy-4}" font-size="22" font-weight="700" fill="${CHART_THEME.darkText}" text-anchor="middle">${total}</text>`;
  svg += `<text x="${cx}" y="${cy+16}" font-size="11" fill="${CHART_THEME.mutedText}" text-anchor="middle">itens</text>`;

  // mini barras à direita com %
  let by = 30;
  counts.forEach(c=>{
    const pct = total? (c.count/total*100):0;
    svg += `<rect x="240" y="${by}" width="10" height="10" rx="2" fill="${STATUS_COLOR[c.status]}"/>`;
    svg += `<text x="256" y="${by+9}" font-size="11" fill="${CHART_THEME.darkText}">${c.status}: ${c.count} (${pct.toFixed(0)}%)</text>`;
    by += 24;
  });

  document.getElementById('m_donutSvg').innerHTML = svg;
  document.getElementById('m_donutLegend').innerHTML = '';
}

// ---------- barras horizontais empilhadas (genérico) ----------
function renderStackedBars(containerId, field, sortDesc=true, maxRows=20){
  const groups = groupCounts(field);
  let rows = Object.keys(groups).map(k=>({label:k, ...groups[k]}));
  rows.sort((a,b)=> sortDesc ? b.total-a.total : a.total-b.total);
  rows = rows.slice(0, maxRows);
  const maxTotal = Math.max(1, ...rows.map(r=>r.total));

  document.getElementById(containerId).innerHTML = rows.map(r=>{
    const segs = STATUS_ORDER.map(s=>{
      const w = (r[s]/maxTotal*100);
      if(w<=0) return '';
      return `<div title="${s}: ${r[s]}" style="width:${w}%;background:${STATUS_COLOR[s]};height:100%;"></div>`;
    }).join('');
    return `<div class="barh-row">
      <div class="barh-label" title="${r.label}">${r.label}</div>
      <div class="barh-track">${segs}</div>
      <div class="barh-total">${r.total}</div>
    </div>`;
  }).join('');
}

function renderSharedStatusLegend(){
  document.getElementById('m_statusLegendShared').innerHTML = STATUS_ORDER.map(s=>
    `<span><span class="dot" style="background:${STATUS_COLOR[s]};"></span>${s}</span>`
  ).join('');
}

// ---------- gargalos (bloqueado + não iniciado por grupo) ----------
function renderGargalos(){
  const groups = groupCounts('grupo');
  let rows = Object.keys(groups).map(k=>{
    const g = groups[k];
    return {label:k, gargalo: (g['Bloqueado']||0)+(g['Não iniciado']||0), total: g.total, bloqueado:g['Bloqueado']||0, naoiniciado:g['Não iniciado']||0};
  }).filter(r=>r.gargalo>0);
  rows.sort((a,b)=>b.gargalo-a.gargalo);
  const maxVal = Math.max(1, ...rows.map(r=>r.gargalo));

  document.getElementById('m_barGargalos').innerHTML = rows.map(r=>{
    const wB = r.bloqueado/maxVal*100, wN = r.naoiniciado/maxVal*100;
    return `<div class="barh-row">
      <div class="barh-label" title="${r.label}">${r.label}</div>
      <div class="barh-track">
        <div title="Bloqueado: ${r.bloqueado}" style="width:${wB}%;background:${STATUS_COLOR['Bloqueado']};height:100%;"></div>
        <div title="Não iniciado: ${r.naoiniciado}" style="width:${wN}%;background:${STATUS_COLOR['Não iniciado']};height:100%;"></div>
      </div>
      <div class="barh-total">${r.gargalo}</div>
    </div>`;
  }).join('') || '<div style="color:var(--muted);font-size:12.5px;">Nenhum gargalo identificado.</div>';
}

// ---------- lead time médio por categoria ----------
function renderLeadTime(){
  const cats = {};
  items.forEach(i=>{
    if(i.status==='Concluído' && typeof i.lead_time==='number'){
      const k = i.categoria || '—';
      if(!cats[k]) cats[k] = {sum:0,count:0};
      cats[k].sum += i.lead_time;
      cats[k].count++;
    }
  });
  let rows = Object.keys(cats).map(k=>({label:k, avg: cats[k].sum/cats[k].count, count:cats[k].count}));
  rows.sort((a,b)=>b.avg-a.avg);
  const maxVal = Math.max(1, ...rows.map(r=>r.avg));

  document.getElementById('m_barLeadTime').innerHTML = rows.map(r=>{
    const w = r.avg/maxVal*100;
    return `<div class="barh-row">
      <div class="barh-label" title="${r.label}">${r.label}</div>
      <div class="barh-track"><div style="width:${w}%;background:#3CB5E4;height:100%;"></div></div>
      <div class="barh-total">${r.avg.toFixed(0)}d</div>
    </div>`;
  }).join('') || '<div style="color:var(--muted);font-size:12.5px;">Sem dados de lead time.</div>';
}

// ---------- itens em atraso ----------
function renderAtrasados(){
  const today = todayISO();
  const atrasados = items.filter(i=> i.status!=='Concluído' && i.prazo && i.prazo < today);
  atrasados.sort((a,b)=> a.prazo.localeCompare(b.prazo));
  document.getElementById('m_atrasadosSub').textContent =
    `${atrasados.length} itens não concluídos com prazo expirado`;
  document.getElementById('m_atrasadosBody').innerHTML = atrasados.map(i=>{
    const diasAtraso = Math.floor((new Date(today+'T00:00:00') - new Date(i.prazo+'T00:00:00'))/(1000*60*60*24));
    return `<tr>
      <td>${i.nome||'—'}</td><td>${i.categoria||'—'}</td><td>${i.grupo||'—'}</td><td>${i.item||'—'}</td>
      <td>${i.responsavel||'—'}</td><td>${fmtDate(i.prazo)}</td>
      <td class="late-tag">${diasAtraso}d</td>
      <td><span class="status-tag ${STATUS_CLASS[i.status]||''}">${i.status||'—'}</span></td>
    </tr>`;
  }).join('') || '<tr><td colspan="8" style="color:var(--muted);">Nenhum item em atraso 🎉</td></tr>';
}

// ---------- tabela completa ----------
function populateFilters(){
  const uniq = (field) => Array.from(new Set(items.map(i=>i[field]).filter(Boolean))).sort();
  document.getElementById('m_categoriaFilter').innerHTML = '<option value="">Todas as categorias</option>' +
    uniq('categoria').map(v=>`<option value="${v}">${v}</option>`).join('');
  document.getElementById('m_grupoFilter').innerHTML = '<option value="">Todos os grupos</option>' +
    uniq('grupo').map(v=>`<option value="${v}">${v}</option>`).join('');
  document.getElementById('m_responsavelFilter').innerHTML = '<option value="">Todos os responsáveis</option>' +
    uniq('responsavel').map(v=>`<option value="${v}">${v}</option>`).join('');
}

function renderTable(){
  const search = document.getElementById('m_searchInput').value.toLowerCase();
  const categoria = document.getElementById('m_categoriaFilter').value;
  const grupo = document.getElementById('m_grupoFilter').value;
  const responsavel = document.getElementById('m_responsavelFilter').value;
  const status = document.getElementById('m_statusFilter').value;

  const filtered = items.filter(i=>{
    if(categoria && i.categoria!==categoria) return false;
    if(grupo && i.grupo!==grupo) return false;
    if(responsavel && i.responsavel!==responsavel) return false;
    if(status && i.status!==status) return false;
    if(search){
      const hay = (((i.nome||'')+' '+(i.item||'')+' '+(i.observacao||'')+' '+(i.grupo||''))).toLowerCase();
      if(!hay.includes(search)) return false;
    }
    return true;
  });

  document.getElementById('m_rowCount').textContent = `${filtered.length} de ${items.length} linhas`;
  if(items.length===0){
    document.getElementById('m_tableBody').innerHTML = '<tr><td colspan="10" style="text-align:center;color:var(--muted);padding:24px;">Nenhuma planilha carregada ainda — use o botão "📋 Mobilização" no topo da página para enviar os dados.</td></tr>';
    return;
  }
  document.getElementById('m_tableBody').innerHTML = filtered.map(i=>`
    <tr>
      <td>${i.nome||'—'}</td><td>${i.categoria||'—'}</td><td>${i.grupo||'—'}</td><td>${i.item||'—'}</td>
      <td>${i.responsavel||'—'}</td><td>${fmtDate(i.data_solicitacao)}</td><td>${fmtDate(i.prazo)}</td>
      <td>${fmtDate(i.data_conclusao)}</td><td>${i.lead_time!=null? i.lead_time+'d':'—'}</td>
      <td><span class="status-tag ${STATUS_CLASS[i.status]||''}">${i.status||'—'}</span></td>
    </tr>`).join('');
}

function renderAll(){
  renderKPIs();
  renderCurva();
  renderDonut();
  renderStackedBars('m_barCategoria','categoria');
  renderStackedBars('m_barGrupo','grupo');
  renderStackedBars('m_barResponsavel','responsavel');
  renderStackedBars('m_barColaborador','nome', true, 20);
  renderSharedStatusLegend();
  renderGargalos();
  renderLeadTime();
  renderAtrasados();
  populateFilters();
  renderTable();
}

['m_searchInput','m_categoriaFilter','m_grupoFilter','m_responsavelFilter','m_statusFilter'].forEach(id=>{
  document.getElementById(id).addEventListener('input', renderTable);
  document.getElementById(id).addEventListener('change', renderTable);
});

return { renderAll, rebuildFromWorkbook };
})();

function setSharedStatus(msg, kind){
  const el = document.getElementById('fileStatus');
  const wrap = document.getElementById('updateConfirmation');
  const icon = kind==='ok' ? '✅ ' : (kind==='err' ? '⚠️ ' : '⏳ ');
  el.textContent = (kind ? icon : '') + msg;
  el.style.color = kind==='ok' ? '#1B7A4A' : (kind==='err' ? '#8a5a00' : '#5C7472');
  wrap.classList.remove('pulse');
  if(kind==='ok'){
    void wrap.offsetWidth; // reinicia a animação mesmo em atualizações seguidas
    wrap.classList.add('pulse');
  }
}

// Upload por processo: cada planilha alimenta apenas a sua área.
// Após atualizar, se a área estiver aberta na tela, todos os painéis (incluindo o
// fluxograma de blocos) são re-renderizados na hora.
function handleAreaUpload(e, area, label){
  const file = e.target.files[0];
  if(!file) return;
  if(typeof XLSX === 'undefined'){
    setSharedStatus('biblioteca de leitura de Excel não carregou', 'err');
    return;
  }
  const reader = new FileReader();
  reader.onload = function(evt){
    try{
      const wb = XLSX.read(new Uint8Array(evt.target.result), {type:'array', cellDates:true});
      const n = AssetDash.rebuildAreaFromWorkbook(wb, area);

      // abre a página do processo atualizado e re-renderiza tudo (fluxograma incluso)
      showPage('page-ativos');
      activateAreaRow(area==='energia' ? 'treeEnergia' : 'treeBritagem');
      AssetDash.setArea(area);
      initZoom('zoomFluxo','a_fluxoSvg');
      initZoom('zoomIndividual','a_curvaIndividualSvg');
      initZoom('zoomConsolidada','a_curvaConsSvg');

      const now = new Date().toLocaleTimeString('pt-BR');
      setSharedStatus(label + ' atualizada manualmente: ' + file.name + ' (' + n + ' itens)', 'ok');
      const tag = document.getElementById('a_lastUpdate');
      if(tag){
        tag.textContent = '🟢 ' + label + ' — última atualização: ' + now + ' · arquivo "' + file.name + '" · ' + n + ' itens carregados (confira os números nos cards acima — se mudaram, a atualização funcionou)';
        tag.classList.add('fresh');
      }
    }catch(err){
      setSharedStatus('erro ao ler ' + file.name + ' (' + label + '): ' + err.message, 'err');
      const tag = document.getElementById('a_lastUpdate');
      if(tag){
        tag.textContent = '🔴 falha ao processar "' + file.name + '" (' + label + '): ' + err.message;
        tag.classList.remove('fresh');
      }
    }
    e.target.value = ''; // permite recarregar o mesmo arquivo
  };
  reader.readAsArrayBuffer(file);
}

document.getElementById('fileInputBritagem').addEventListener('change', function(e){
  handleAreaUpload(e, 'britagem', 'Britagem III');
});
document.getElementById('fileInputEnergia').addEventListener('change', function(e){
  handleAreaUpload(e, 'energia', 'Energia');
});

document.getElementById('fileInputMobilizacao').addEventListener('change', function(e){
  const file = e.target.files[0];
  if(!file) return;
  if(typeof XLSX === 'undefined'){
    setSharedStatus('biblioteca de leitura de Excel não carregou', 'err');
    return;
  }
  const reader = new FileReader();
  reader.onload = function(evt){
    try{
      const wb = XLSX.read(new Uint8Array(evt.target.result), {type:'array', cellDates:true});
      const n = MobDash.rebuildFromWorkbook(wb);
      MobDash.renderAll();
      const now = new Date().toLocaleTimeString('pt-BR');
      setSharedStatus('Controle de Mobilização atualizado manualmente: ' + file.name + ' (' + n + ' itens)', 'ok');
      const tag = document.getElementById('m_lastUpdate');
      tag.textContent = '🟢 última atualização: ' + now + ' · arquivo "' + file.name + '" · ' + n + ' itens carregados (confira os números nos cards acima — se mudaram, a atualização funcionou)';
      tag.classList.add('fresh');
    }catch(err){
      setSharedStatus('erro ao ler ' + file.name + ': ' + err.message, 'err');
      const tag = document.getElementById('m_lastUpdate');
      tag.textContent = '🔴 falha ao processar "' + file.name + '": ' + err.message;
      tag.classList.remove('fresh');
    }
  };
  reader.readAsArrayBuffer(file);
});

document.getElementById('themeToggle').addEventListener('click', function(){
  const isDark = document.body.classList.toggle('dark-mode');
  this.textContent = isDark ? '☀️' : '🌙';
  applyDarkChartTheme(isDark);
  AssetDash.renderAll();
  MobDash.renderAll();
});

document.getElementById('sidebarToggle').addEventListener('click', function(){
  document.body.classList.toggle('sidebar-expanded');
});

document.getElementById('dataUpdateToggle').addEventListener('click', function(e){
  e.stopPropagation();
  document.getElementById('dataUpdatePop').classList.toggle('open');
});
document.addEventListener('click', function(e){
  const pop = document.getElementById('dataUpdatePop');
  const btn = document.getElementById('dataUpdateToggle');
  if(pop.classList.contains('open') && !pop.contains(e.target) && e.target!==btn){
    pop.classList.remove('open');
  }
});

function showPage(pageId){
  document.querySelectorAll('.page-content').forEach(p=>p.classList.toggle('active', p.id===pageId));
  document.querySelectorAll('.tree-row[data-page]').forEach(r=>r.classList.toggle('active', r.dataset.page===pageId));
}

document.getElementById('treePlanejamentos').addEventListener('click', function(){
  const children = document.getElementById('treePlanejamentosChildren');
  const chev = document.getElementById('treePlanejamentosChev');
  const open = children.classList.toggle('open');
  chev.textContent = open ? '▾' : '▸';
});

function activateAreaRow(id){
  ['treeBritagem','treeEnergia'].forEach(x=>{
    document.getElementById(x).classList.toggle('active', x===id);
  });
}

document.getElementById('treeBritagem').addEventListener('click', function(){
  showPage('page-ativos');
  activateAreaRow('treeBritagem');
  AssetDash.setArea('britagem');
});

document.getElementById('treeEnergia').addEventListener('click', function(){
  showPage('page-ativos');
  activateAreaRow('treeEnergia');
  AssetDash.setArea('energia');
});

document.getElementById('treeMobilizacao').addEventListener('click', function(){
  showPage('page-mobilizacao');
  activateAreaRow(null);
});

AssetDash.renderAll();
MobDash.renderAll();
initExpand();
initDownloadButtons();
document.getElementById('pdfReportBtn').addEventListener('click', function(){
  AssetDash.generatePdfReport(this);
});
initZoom('zoomFluxo','a_fluxoSvg');
initZoom('zoomIndividual','a_curvaIndividualSvg');
initZoom('zoomConsolidada','a_curvaConsSvg');
initZoom('zoomIndividual_fs','a_curvaIndividualSvg_fs');
initZoom('zoomConsolidada_fs','a_curvaConsSvg_fs');
setSharedStatus('nenhuma planilha carregada - selecione um arquivo acima', 'muted');
